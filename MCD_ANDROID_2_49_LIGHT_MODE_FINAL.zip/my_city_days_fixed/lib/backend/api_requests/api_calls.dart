import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GenerateTripCall {
  static Future<ApiCallResponse> call({
    String? city = '',
    String? days = '',
    String? interests = '',
    String? language = '',
  }) async {
    final ffApiRequestBody = '''
{
  "city": "${escapeStringForJson(city)}",
  "days": "${escapeStringForJson(days)}",
  "interests": "${escapeStringForJson(interests)}",
  "language": "${escapeStringForJson(language)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GenerateTrip',
      apiUrl:
          'https://pnkkddcqqsgfsjrtoabv.supabase.co/functions/v1/generate-trip-release-test',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? itinerary(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.itinerary''',
      ));
}


class GenerateTripPlanCall {
  static Future<ApiCallResponse> call({
    String? city = '',
    String? days = '',
    String? interests = '',
    String? language = '',
  }) async {
    final ffApiRequestBody = '''
{
  "city": "${escapeStringForJson(city)}",
  "days": "${escapeStringForJson(days)}",
  "interests": "${escapeStringForJson(interests)}",
  "language": "${escapeStringForJson(language)}"
}''';

    return ApiManager.instance.makeApiCall(
      callName: 'GenerateTripPlan',
      apiUrl:
          'https://pnkkddcqqsgfsjrtoabv.supabase.co/functions/v1/generate-trip-plan',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static List<String> dayPlans(dynamic response) {
    final value = getJsonField(response, r'''$.dayPlans''', true);
    if (value is! List) return const <String>[];
    return value.map((item) => item.toString()).toList();
  }
}

class GenerateTripDayCall {
  static Future<ApiCallResponse> call({
    String? city = '',
    int? totalDays,
    int? dayNumber,
    String? dayPlan = '',
    String? interests = '',
    String? language = '',
  }) async {
    final ffApiRequestBody = '''
{
  "city": "${escapeStringForJson(city)}",
  "totalDays": ${totalDays ?? 1},
  "dayNumber": ${dayNumber ?? 1},
  "dayPlan": "${escapeStringForJson(dayPlan)}",
  "interests": "${escapeStringForJson(interests)}",
  "language": "${escapeStringForJson(language)}"
}''';

    return ApiManager.instance.makeApiCall(
      callName: 'GenerateTripDay',
      apiUrl:
          'https://pnkkddcqqsgfsjrtoabv.supabase.co/functions/v1/generate-trip-day',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? itineraryDay(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.itineraryDay''',
      ));
}


class ResolveMapStopsCall {
  static Future<ApiCallResponse> call({
    required String city,
    required List<String> stops,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ResolveMapStops',
      apiUrl: 'https://pnkkddcqqsgfsjrtoabv.supabase.co/functions/v1/resolve-map-stops',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: jsonEncode({'city': city, 'stops': stops}),
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  // Supabase resolve-map-stops returns {city, total, resolved, stops: [...]},
  // where each stop has status resolved/unresolved/error. Never treat an
  // unresolved or errored stop as a navigation waypoint.
  static List<dynamic> verified(dynamic response) {
    final value = getJsonField(response, r'$.stops', true);
    if (value is! List) return const [];
    return value.where((item) => item is Map &&
        item['status'] == 'resolved' &&
        (item['placeId'] ?? '').toString().isNotEmpty &&
        (item['address'] ?? '').toString().isNotEmpty).toList();
  }
}

class GetPlacePhotoCall {
  static Future<ApiCallResponse> call({
    required String city,
    required String place,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'GetPlacePhoto',
      apiUrl: 'https://pnkkddcqqsgfsjrtoabv.supabase.co/functions/v1/get-place-photo',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: jsonEncode({'city': city, 'place': place}),
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? photoUrl(dynamic response) =>
      castToType<String>(getJsonField(response, r'''$.photoUrl'''));

  static List<dynamic> attributions(dynamic response) {
    final value = getJsonField(response, r'''$.authorAttributions''', true);
    return value is List ? value : const [];
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
