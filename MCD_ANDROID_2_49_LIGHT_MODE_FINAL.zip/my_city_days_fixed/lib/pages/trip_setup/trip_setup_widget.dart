import 'dart:async';

import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import '/pages/my_trip/my_trip_widget.dart' show SavedTripsPage;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'trip_setup_model.dart';
export 'trip_setup_model.dart';

class TripSetupWidget extends StatefulWidget {
  const TripSetupWidget({super.key});

  static String routeName = 'TripSetup';
  static String routePath = '/tripSetup';

  @override
  State<TripSetupWidget> createState() => _TripSetupWidgetState();
}

class _TripSetupWidgetState extends State<TripSetupWidget> {
  late TripSetupModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  late final TextEditingController _customCityController;
  late final FocusNode _customCityFocusNode;
  bool _showAllHiddenGems = false;
  String _foodPreference = 'No Preference';

  static const String _oneTripProductId = 'com.abisheva.mycitydays.onetrip';
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;
  ProductDetails? _oneTripProduct;
  bool _storeAvailable = false;
  bool _purchaseInProgress = false;
  bool _purchaseRequested = false;
  bool _paywallOpen = false;
  String? _pendingPurchasedItinerary;
  String? _pendingPurchasedCity;

  final popularCities = const [
    'New York',
    'Paris',
    'Tokyo',
    'Rome',
    'London',
    'Barcelona',
    'Dubai',
    'Istanbul',
    'San Francisco',
    'San Diego',
  ];
  final hiddenGemCities = const [
    'Santa Barbara',
    'Savannah',
    'Portland, Maine',
    'Ljubljana',
    'Bologna',
    'Zaragoza',
    'Tbilisi',
    'Plovdiv',
    'Almaty',
    'Tashkent',
    'Samarkand',
    'Bukhara',
    'Kanazawa',
    'Fukuoka',
    'Busan',
    'Gyeongju',
    'Chengdu',
    'Chongqing',
    'Shenzhen',
  ];
  final interestOptions = const ['Food', 'Culture', 'Shopping', 'Nature', 'Hiking & Nature', 'Local Gems', 'Local Markets'];
  String _interestLabel(String interest) {
    if (interest != 'Hiking & Nature') return interest;
    switch (_model.language) {
      case 'Russian': return 'Хайкинг и природа';
      case 'Turkish': return 'Doğa yürüyüşü ve doğa';
      case 'Spanish': return 'Senderismo y naturaleza';
      case 'French': return 'Randonnée et nature';
      case 'Simplified Chinese': return '徒步与自然';
      default: return 'Hiking & Nature';
    }
  }

  final languageOptions = const ['English', 'Russian', 'Turkish', 'Simplified Chinese', 'Spanish', 'French'];
  final foodPreferenceOptions = const ['No Preference', 'Vegetarian', 'Vegan'];
  final transportOptions = const ['Walking + Public Transit', 'Rideshare', 'Car'];

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TripSetupModel());
    _customCityController = TextEditingController();
    _customCityFocusNode = FocusNode();
    _initStore();
  }

  Future<void> _initStore() async {
    if (kIsWeb) return;

    _purchaseSubscription = _iap.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: (Object error) {
        if (!mounted) return;
        setState(() => _purchaseInProgress = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Purchase error: $error')),
        );
      },
    );

    try {
      final available = await _iap.isAvailable();
      if (!mounted) return;
      if (!available) {
        setState(() => _storeAvailable = false);
        return;
      }

      final response = await _iap.queryProductDetails({_oneTripProductId});
      if (!mounted) return;
      setState(() {
        _storeAvailable = response.error == null && response.productDetails.isNotEmpty;
        _oneTripProduct = response.productDetails.isEmpty ? null : response.productDetails.first;
      });
    } catch (_) {
      if (mounted) setState(() => _storeAvailable = false);
    }
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.productID != _oneTripProductId) continue;

      if (purchase.status == PurchaseStatus.pending) {
        if (mounted) setState(() => _purchaseInProgress = true);
        continue;
      }

      if (purchase.status == PurchaseStatus.error ||
          purchase.status == PurchaseStatus.canceled) {
        if (mounted) {
          setState(() => _purchaseInProgress = false);
          if (purchase.status == PurchaseStatus.error) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(purchase.error?.message ?? 'Purchase could not be completed.')),
            );
          }
        }
        _purchaseRequested = false;
      }

      if (purchase.status == PurchaseStatus.purchased) {
        if (purchase.pendingCompletePurchase) {
          await _iap.completePurchase(purchase);
        }

        final shouldUnlockTrip = _purchaseRequested;
        final purchasedItinerary = _pendingPurchasedItinerary;
        final purchasedCity = _pendingPurchasedCity;
        _purchaseRequested = false;
        _pendingPurchasedItinerary = null;
        _pendingPurchasedCity = null;
        if (!mounted) return;
        setState(() => _purchaseInProgress = false);

        if (shouldUnlockTrip && purchasedItinerary != null) {
          if (Navigator.of(context).canPop()) {
            Navigator.of(context).pop();
          }
          context.goNamed(MyTripWidget.routeName, queryParameters: {
            'itineraryId': serializeParam(purchasedItinerary, ParamType.String),
            'city': serializeParam(purchasedCity ?? (_model.city ?? 'Your Trip'), ParamType.String),
            'travelMode': serializeParam(_model.gettingAround ?? 'Walking + Public Transit', ParamType.String),
          }.withoutNulls);
        }
      } else if (purchase.pendingCompletePurchase) {
        await _iap.completePurchase(purchase);
      }
    }
  }

  @override
  void dispose() {
    _purchaseSubscription?.cancel();
    _customCityController.dispose();
    _customCityFocusNode.dispose();
    _model.dispose();
    super.dispose();
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(
          text,
          style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
      );

  Widget _choiceChip(String label, bool selected, VoidCallback onTap) {
    return ChoiceChip(
      label: Text(label),
      avatar: selected
          ? Icon(Icons.check_rounded, size: 16, color: FlutterFlowTheme.of(context).onPrimary)
          : null,
      selected: selected,
      showCheckmark: false,
      backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
      selectedColor: FlutterFlowTheme.of(context).primary,
      side: BorderSide.none,
      labelStyle: TextStyle(
        color: selected ? FlutterFlowTheme.of(context).onPrimary : FlutterFlowTheme.of(context).primaryText,
        fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      onSelected: (_) => onTap(),
    );
  }

  Future<void> _createTrip() async {
    if (_model.isLoading == true || _purchaseInProgress) return;
    if ((_model.city ?? '').isEmpty ||
        (_model.language ?? '').isEmpty ||
        _model.interests.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose a city, interests and language.')),
      );
      return;
    }

    await _generateTrip();
  }

  Future<void> _showPaywall() async {
    final price = _oneTripProduct?.price ?? r'$2.49';

    _paywallOpen = true;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 42,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 22),
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).alternate,
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.explore_rounded,
                        color: FlutterFlowTheme.of(context).primary,
                        size: 30,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Your personalized trip is ready',
                      style: FlutterFlowTheme.of(context).headlineSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Before you purchase, here’s exactly what is included in your one-time trip purchase.',
                      style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                            color: FlutterFlowTheme.of(context).secondaryText,
                            height: 1.45,
                          ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'What you’ll get',
                      style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 10),
                    _paywallFeature(Icons.route_rounded, 'Personalized day-by-day itinerary'),
                    _paywallFeature(Icons.restaurant_rounded, 'Recommendations, food spots & local gems'),
                    _paywallFeature(Icons.lightbulb_outline_rounded, 'Practical travel tips for your destination'),
                    _paywallFeature(Icons.map_rounded, 'Google Maps routes for your days'),
                    _paywallFeature(Icons.picture_as_pdf_rounded, 'Downloadable My City Days guide'),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        'One-time in-app purchase · $price per trip · No subscription',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                              fontWeight: FontWeight.w700,
                              color: FlutterFlowTheme.of(context).primaryText,
                            ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('One personalized trip',
                                    style: FlutterFlowTheme.of(context).bodyLarge.copyWith(
                                          fontWeight: FontWeight.w700,
                                        )),
                                const SizedBox(height: 3),
                                Text('One-time purchase',
                                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                                          color: FlutterFlowTheme.of(context).secondaryText,
                                        )),
                              ],
                            ),
                          ),
                          Text(
                            price,
                            style: FlutterFlowTheme.of(context).titleLarge.copyWith(
                                  fontWeight: FontWeight.w800,
                                ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 56,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: FlutterFlowTheme.of(context).primary,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        onPressed: _purchaseInProgress
                            ? null
                            : () async {
                                setSheetState(() => _purchaseInProgress = true);
                                if (mounted) {
                                  setState(() => _purchaseInProgress = true);
                                }
                                Navigator.of(sheetContext).pop();
                                _paywallOpen = false;
                                if (mounted) {
                                  setState(() => _purchaseInProgress = false);
                                }
                                await _generateTrip();
                              },
                        child: _purchaseInProgress
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Create My Trip · $price',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Internal test · No payment will be charged. Tap the button to continue.',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                            color: FlutterFlowTheme.of(context).secondaryText,
                          ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
    _paywallOpen = false;
  }

  Widget _paywallFeature(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, size: 19, color: FlutterFlowTheme.of(context).tertiary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  // Keep the AI request concise and conditional. Mai writes the guide directly
  // in the chosen language; the UI owns map links, PDF and paywall formatting.
  // Mai Language Quality: give native-language editorial directions, rather
  // than treating English prose as the intermediate version of the guide.
  // Only language instructions change here; places, route, maps and PDF remain
  // the responsibility of the existing itinerary flow.
  String _buildNativeLanguageInstructions() {
    const nativeBriefs = <String, String>{
      'English': '''Write the entire travel guide originally in idiomatic English, with the clear, vivid, restrained voice of a professional local travel writer. Do not translate another-language draft. Use natural everyday travel terms rather than marketing jargon, jargon-heavy labels, vague filler or awkward constructions. Preserve official place, street and transport names for map search. Read the completed guide once for grammatical consistency, fluent headings, and accidental internal notes. Finish with the guide itself, not a question or invitation to chat.''',
      'Russian': '''Напиши весь путеводитель сразу по-русски, как опытный русскоязычный автор о путешествиях. Не составляй английский черновик и не переводи его. Пиши живым, естественным, грамотным языком: короткие ясные предложения, привычные названия городских мест, без канцелярита, англицизмов-калек, искусственных слов и рекламных штампов. Описывай конкретные впечатления, а не абстрактные «гастрономические точки» или «квартальные места». Географические названия, названия заведений и транспорта сохраняй в официальном написании для поиска на карте. Проверь падежи, согласование, заголовки, связность и единый стиль. Не показывай технические команды, пояснения для модели и предложения продолжить разговор. Ответ — только готовый путеводитель.''',
      'Turkish': '''Gezi rehberinin tamamını doğrudan doğal ve akıcı Türkçe yaz. Önce İngilizce yazıp sonra çeviri yapma. Yerel gezi yazarı gibi sade, anlaşılır ve özenli bir üslup kullan; kelimesi kelimesine çeviri, yapay ifadeler, gereksiz yabancı sözcükler ve klişeler kullanma. Sokak, mekân ve toplu taşıma adlarını haritada bulunabilecek resmî biçimiyle koru. Başlıkları, ekleri, cümle akışını ve anlatımın doğallığını kontrol et. İç yönergeler veya sohbeti sürdürme teklifleri ekleme; yalnızca tamamlanmış gezi rehberini sun.''',
      'Spanish': '''Redacta toda la guía directamente en español natural, con el estilo claro y preciso de una persona local que escribe sobre viajes. No redactes primero en inglés ni traduzcas literalmente. Usa expresiones idiomáticas, frases claras y descripciones concretas; evita calcos, palabras inventadas, etiquetas artificiales y clichés promocionales. Conserva los nombres oficiales de lugares, calles y transportes para encontrarlos en el mapa. Revisa concordancia, gramática, títulos y fluidez antes de entregar el texto. No muestres instrucciones internas ni invitaciones a seguir conversando: entrega únicamente la guía completa.''',
      'French': '''Rédige l’intégralité du guide directement dans un français naturel, précis et agréable, comme une personne du pays qui connaît bien les voyages. Ne prépare pas de brouillon anglais et ne traduis pas mot à mot. Préfère des phrases fluides, des termes usuels et des descriptions concrètes ; évite les calques, formulations artificielles, mots inventés et slogans. Conserve les noms officiels des lieux, rues et transports pour la recherche sur la carte. Relis les accords, la syntaxe, les titres et la cohérence du style. Ne montre aucune consigne interne ni proposition de poursuivre la conversation : livre uniquement le guide terminé.''',
      'Simplified Chinese': '''请直接使用自然、准确、地道的简体中文撰写完整旅行指南，不要先写英文再逐句翻译。采用熟悉当地情况的旅行作者的表达方式，语言清晰、具体、流畅；避免生硬直译、杜撰词语、营销套话和空洞描述。景点、街道、交通站点和商家名称保留便于地图搜索的官方名称。提交前检查语法、措辞、标题、连贯性以及是否混入英文指令。不要输出内部说明、技术标记或继续聊天的邀请，只提供完成的旅行指南。''',
    };
    return nativeBriefs[_model.language ?? 'English'] ?? nativeBriefs['English']!;
  }

  String _buildGuideInstructions() {
    final selectedInterests = _model.interests.join(', ');
    final mobility = _model.gettingAround ?? 'Walking + Public Transit';
    final rules = <String>[
      'TRAVELER PREFERENCES: Interests: $selectedInterests. Transportation: $mobility.',
      'TASK: Return one COMPLETE, useful, polished day-by-day city itinerary, not a conversation. Do not ask questions, apologize for not being a human, invite follow-up or describe how you generated it. If insufficient reliable information exists, return an explicit failure instead of inventing places.',
      'DESTINATION AND GEOGRAPHY: Every numbered stop must be a real, geographically valid and map-searchable place. Check that stops belong to the SAME requested city, shore or district and that walking/transit times are realistic; never combine distant shores of Lake Tahoe (e.g. Commons Beach in Tahoe City and Heavenly Village in South Lake Tahoe) as if they were a short walk. Order stops to minimize backtracking. If the user has no car, use plausible local transit options only, not invented bus routes or schedules. Do not invent venue names, prices, opening hours or sources. No intercity excursions unless explicitly requested.',
      'STRUCTURE: Start with city name and a short overview. Label each day clearly (Day 1 / equivalent in the selected language). Each day has a short natural title, logical schedule and a numbered list of real attractions: 1) Official Place Name; 2) Official Place Name; etc. Restart numbering at 1 each day. Each attraction includes estimated visit time, approximate duration, why to go, and directions to the next stop. Keep descriptions precise and genuinely useful.',
      'NUMBERING: Only actual map-ready attraction/activity stops receive numbers. Meals, coffee, restaurants, generic breaks, transportation, practical tips and optional nearby shops must NOT be numbered. Do NOT print instructions such as NO NUMBERING, unnumbered, TODO, placeholders or model notes in the guide.',
      'STYLE: Write concise, fluent native-language travel editorial prose. Avoid literal English translations, nonsense words, unnatural category labels, robotic repetition and phrases such as independent coffee shop translated mechanically. Never use placeholders (e.g., some cafe, such-and-such dishes) as if they were specific recommendations. Do not repeat redundant Official Name and Why Visit labels for every stop.',
      'FOOD: Add useful optional meal suggestions separate from the numbered attraction route; name actual verified restaurants only when reliable, otherwise recommend the cuisine or neighborhood without inventing a venue. Never claim a menu item is available without evidence.',
      'FACTS: Say Free entry or Paid entry only when reasonably supported. Provide exact admission prices and official websites only when reliable; otherwise state that price is unconfirmed and should be verified on the official site. Use realistic walking and transport guidance; no invented schedules.',
      'END: Short practical Getting Around, local tips, bookings and estimated daily budget only where useful. No chatty concluding question or offer to do more.'
    ];
    if (_foodPreference == 'Vegetarian') {
      rules.add('DIET: Vegetarian. Exclude meat, poultry, fish and seafood in meal suggestions; eggs and dairy may be included. If a menu cannot be verified, say so rather than claiming compliance.');
    } else if (_foodPreference == 'Vegan') {
      rules.add('DIET: Vegan. Exclude meat, poultry, fish, seafood, dairy, eggs, honey and animal-derived ingredients in meal suggestions. If a menu cannot be verified, say so rather than claiming compliance.');
    }
    if (_model.interests.contains('Local Gems')) {
      rules.add('LOCAL GEMS: Add distinctive local discoveries that genuinely improve the experience. If other interests are selected, blend them naturally with the city’s iconic, worthwhile sights. Never exclude major landmarks just because they are famous. If Local Gems is the only interest, emphasize authentic local places, but still choose the most memorable experiences rather than filler.');
    }
    if ((_model.interests.contains('Hiking & Nature') || _model.interests.contains('Hiking'))) {
      rules.add('HIKING & NATURE (SELECTED INTEREST): Include real, named, map-searchable nature walks, hiking trails, canyons, forests, lakes, coastal paths and scenic viewpoints suited to the requested city and available transport, not only generic parks or photo stops. For each suggested trail provide trailhead name/location, approximate length in km and miles, estimated walking time, difficulty, elevation gain when reliable, surface/steepness and useful weather/seasonal cautions. Mention permits, entrance or parking charges only if verifiable; otherwise clearly mark as unconfirmed. Prefer official parks/trail authorities as the primary factual source; use AllTrails only as a supporting reference when available, not as evidence of current access. Never invent a trail, a transit service, open status or a safety guarantee. For Walking + Public Transit, prioritize trailheads realistically reachable on foot or transit; if access without a car is uncertain, say so and recommend an accessible alternative rather than inventing a bus connection. Avoid closed, unsafe, restricted, or excessively difficult trails; route times should allow for return travel and daylight. If trail details cannot be established, plainly say so instead of fabricating precise numbers.');
    }
    if (_model.interests.contains('Local Gems') &&
        (_model.interests.contains('Hiking & Nature') || _model.interests.contains('Hiking'))) {
      rules.add('LOCAL GEMS + HIKING & NATURE: Combine distinctive local trails and scenic places with exceptional well-known nature experiences when they genuinely fit the traveler. Favor quality, accessibility and realistic routing over obscurity.');
    }
    if (_model.interests.contains('Local Markets')) {
      rules.add('LOCAL MARKETS: Add a short separate OPTIONAL Nearby Local Markets section with genuinely nearby food markets or supermarkets. Include real searchable names and addresses when reliable. These are not numbered sightseeing stops. Avoid detours and invented stores or hours.');
    }
    return rules.join('\n\n');
  }

  Future<void> _generateTrip() async {
    if (_model.isLoading == true) return;
    setState(() => _model.isLoading = true);
    try {
      final dayCount = _model.days ?? 2;
      final interests = _buildGuideInstructions();
      final language = _buildNativeLanguageInstructions();

      // One request creates the complete multi-day trip, preserving shared context.
      final tripResponse = await GenerateTripCall.call(
        city: _model.city,
        days: dayCount.toString(),
        interests: interests,
        language: language,
      );
      if (!mounted) return;
      if (!tripResponse.succeeded) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Trip generation failed (${tripResponse.statusCode}).')),
        );
        return;
      }
      final itinerary =
          GenerateTripCall.itinerary(tripResponse.jsonBody)?.trim() ?? '';

      // Preserve the existing quality gate and purchase/preview flow.
      final normalized = itinerary.toLowerCase();
      final hasDay = RegExp(r'(day\s*1|день\s*1|gün\s*1|día\s*1|jour\s*1|第[一1]天)', caseSensitive: false).hasMatch(itinerary);
      final looksLikeChat = normalized.contains('quick question') ||
          normalized.contains('before i build') ||
          normalized.contains('would you like me') ||
          normalized.contains('let me know if') ||
          normalized.contains('do you want me to') ||
          normalized.contains('хотите, чтобы я') ||
          normalized.contains('isterseniz') ||
          normalized.contains('нет нумерации') ||
          normalized.contains('no numbering') ||
          normalized.contains('булочнойми') ||
          normalized.contains('дентра с намеской') ||
          normalized.contains('такие-то') ||
          normalized.contains('независимую кафейню');
      if (itinerary.isEmpty || !hasDay || looksLikeChat) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('We could not complete a reliable itinerary. Please retry; no purchase was made.')),
        );
        return;
      }

      await _showTripPreview(itinerary);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not create trip: $e')),
      );
    } finally {
      if (mounted) setState(() => _model.isLoading = false);
    }
  }

  // Display model content as data rather than asking Mai to format the UI.
  // Tolerate numbered stops with Markdown, localized punctuation and section headings.
  Map<String, String> _firstPreviewStop(String itinerary) {
    // Extract the first *real* stop without relying on English labels, Markdown,
    // or a particular numbering separator. Keep source text unchanged for My Trips.
    final lines = itinerary.replaceAll('\r\n', '\n').split('\n');
    final dayPattern = RegExp(
      r'(?:\bday\s*(?:1|one)\b|\bдень\s*1\b|\b1\s*[-.]?\s*(?:й|ый)?\s*день\b|\b(?:gün\s*1|1\s*\.?\s*gün)\b|\b(?:día\s*1|1\s*\.?\s*día)\b|\b(?:jour\s*1|1\s*er?\s*jour)\b|第[一1]天|第一日)',
      caseSensitive: false,
    );
    final stopPattern = RegExp(
      r'^\s*(?:[-*•]\s*)?(?:(?:stop|остановка|parada|arrêt|durak|站点|景点)\s*)?([1１])\s*[.)\-:、．]\s*(.+)$',
      caseSensitive: false,
    );
    final boldNumber = RegExp(r'^\s*\*\*\s*([1１])\s*[.)\-:、．]\s*(.+)');
    final numberedHeading = RegExp(r'^\s*#{1,6}\s*(?:[1１]\s*[.)\-:、．]\s*)?(.+)$');
    final timePattern = RegExp(r'\b(?:0?[7-9]|1[0-9]|2[0-3])[:.][0-5][0-9]\b');
    final numberedCandidates = <int>[];
    final headingCandidates = <int>[];
    var firstDayIndex = -1;

    String clean(String raw) => raw.trim()
        .replaceAll(RegExp(r'^#{1,6}\s*'), '')
        .replaceAll(RegExp(r'\*\*|__|`'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    bool isInvalidTitle(String value) {
      final v = value.toLowerCase().trim();
      if (v.length < 3 || dayPattern.hasMatch(v)) return true;
      return RegExp(
        r'^(?:theme|тема|транспорт|transport|time|время|продолжительность|duration|'
        r'getting around|local tips|good to know|food|breakfast|lunch|dinner|'
        r'завтрак|обед|ужин|советы|как добраться|budget|бюджет|'
        r'my city days|overview|маршрут|itinéraire|itinerary|resumen|özet)\b',
        caseSensitive: false,
      ).hasMatch(v);
    }

    for (var i = 0; i < lines.length; i++) {
      final raw = lines[i].trim();
      if (firstDayIndex < 0 && dayPattern.hasMatch(clean(raw))) {
        firstDayIndex = i;
        continue;
      }
      final plain = clean(raw);
      if (stopPattern.hasMatch(plain) || boldNumber.hasMatch(raw)) {
        numberedCandidates.add(i);
      } else if (numberedHeading.hasMatch(raw) && !isInvalidTitle(plain)) {
        headingCandidates.add(i);
      }
    }

    // Prefer stop #1 after the first day heading, but tolerate server output
    // without that exact heading. A generic bold section is the last fallback.
    int? index;
    for (final candidate in numberedCandidates) {
      if (candidate > firstDayIndex) { index = candidate; break; }
    }
    if (index == null && numberedCandidates.isNotEmpty) index = numberedCandidates.first;
    if (index == null) {
      for (final candidate in headingCandidates) {
        if (candidate > firstDayIndex && !isInvalidTitle(clean(lines[candidate]))) {
          index = candidate;
          break;
        }
      }
    }
    if (index == null) return {};

    final raw = lines[index].trim();
    final plain = clean(raw);
    String title = stopPattern.firstMatch(plain)?.group(2) ??
        boldNumber.firstMatch(raw)?.group(2) ??
        numberedHeading.firstMatch(raw)?.group(1) ?? '';
    title = clean(title).replaceFirst(RegExp(r'^[1１]\s*[.)\-:、．]\s*'), '');
    if (isInvalidTitle(title)) return {};

    final details = <String>[];
    var time = '';
    for (var j = index + 1; j < lines.length && j < index + 15; j++) {
      final next = clean(lines[j]);
      if (next.isEmpty) {
        if (details.isNotEmpty) break;
        continue;
      }
      if (dayPattern.hasMatch(next) || stopPattern.hasMatch(next) ||
          boldNumber.hasMatch(lines[j]) || lines[j].trimLeft().startsWith('#')) break;
      if (time.isEmpty) time = timePattern.firstMatch(next)?.group(0) ?? '';
      details.add(next.replaceFirst(RegExp(r'^[-*•]\s*'), ''));
      if (details.join(' ').length >= 340) break;
    }
    return {'title': title, 'description': details.join(' ').trim(), 'time': time};
  }

  // Preview is a city introduction, not stop #1 (which is often breakfast).
  // Read only the introductory section of Mai's *already generated* itinerary.
  String _cityPreviewOverview(String itinerary) {
    final lines = itinerary.replaceAll('\r', '').split('\n');
    final dayHeading = RegExp(
      r'^(?:#{1,6}\s*)?(?:\*\*)?\s*(?:day\s*[1-9]|день\s*[1-9]|gün\s*[1-9]|día\s*[1-9]|jour\s*[1-9]|第[一二三四五六七八九1-9]天)',
      caseSensitive: false,
    );
    final intro = <String>[];
    for (final raw in lines) {
      final line = raw.trim().replaceAll(RegExp(r'^(?:#{1,6}\s*|[-*•]\s*)'), '')
          .replaceAll('**', '').replaceAll('__', '').trim();
      if (dayHeading.hasMatch(line)) break;
      if (line.isEmpty) continue;
      final lower = line.toLowerCase();
      if (lower == 'my city days' || lower.contains('personal travel guide') ||
          lower.startsWith('travel information disclaimer') ||
          RegExp(r'^(?:сан[-‑ ]франциско|san francisco|lake tahoe|san diego)\s*[-—:]?$', caseSensitive: false).hasMatch(line)) continue;
      // Skip section headers but keep the substantive summary below them.
      if (RegExp(r'^(?:краткий обзор|overview|обзор города|introduction|introduction à|resumen|genel bakış)', caseSensitive: false).hasMatch(line) && line.length < 80) continue;
      if (line.length < 28 && !line.contains('.') && !line.contains('!')) continue;
      intro.add(line);
      if (intro.join(' ').length > 500) break;
    }
    final summary = intro.join(' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (summary.length >= 65) {
      return summary.length > 480 ? '${summary.substring(0, 477).trimRight()}…' : summary;
    }
    // Safe generic fallback: never invent an attraction or claim a verified fact.
    switch (_model.language) {
      case 'Russian': return 'Откройте ${_model.city ?? 'город'} в своём ритме: персональный маршрут по выбранным интересам, с удобной последовательностью остановок и полезными советами для поездки.';
      case 'Turkish': return '${_model.city ?? 'Şehri'} kendi ritminizde keşfedin. İlgi alanlarınıza göre hazırlanmış günlük rota, gezi önerileri ve pratik ipuçları sizi bekliyor.';
      case 'Spanish': return 'Descubre ${_model.city ?? 'la ciudad'} a tu ritmo con un itinerario adaptado a tus intereses, rutas por día y consejos prácticos.';
      case 'French': return 'Découvrez ${_model.city ?? 'la ville'} à votre rythme avec un itinéraire adapté à vos envies, des étapes organisées et des conseils pratiques.';
      case 'Simplified Chinese': return '按照自己的节奏探索${_model.city ?? '这座城市'}。根据你的兴趣安排每日行程，享受便捷的路线和实用旅行建议。';
      default: return 'Discover ${_model.city ?? 'your destination'} at your own pace with a personalized day-by-day guide, thoughtful routes and practical travel tips.';
    }
  }

  Future<void> _showTripPreview(String itinerary) async {
    final overview = _cityPreviewOverview(itinerary);
    final city = _model.city ?? 'Your Trip';
    final days = _model.days ?? 2;
    final theme = FlutterFlowTheme.of(context);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) => SafeArea(
        top: false,
        child: Container(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(sheetContext).height * .91),
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 18),
          decoration: BoxDecoration(
            color: theme.primaryBackground,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(color: theme.alternate, borderRadius: BorderRadius.circular(30)),
                )),
                const SizedBox(height: 18),
                Text('MY CITY DAYS  ·  PREVIEW', style: theme.bodySmall.copyWith(
                  color: theme.secondaryText, fontWeight: FontWeight.w700, letterSpacing: 1.2,
                )),
                const SizedBox(height: 9),
                Text(city.toUpperCase(), style: theme.headlineMedium.copyWith(fontWeight: FontWeight.w800)),
                Text('$days-day personalized itinerary', style: theme.bodyMedium.copyWith(color: theme.secondaryText)),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    color: theme.secondaryBackground,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: theme.alternate),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Icon(Icons.auto_awesome_outlined, color: theme.primary, size: 20),
                      const SizedBox(width: 8),
                      Expanded(child: Text('DISCOVER YOUR CITY', style: theme.bodySmall.copyWith(
                        color: theme.secondaryText, fontWeight: FontWeight.w700, letterSpacing: .7,
                      ))),
                    ]),
                    const SizedBox(height: 12),
                    Text(overview, style: theme.bodyMedium.copyWith(height: 1.55)),
                    const SizedBox(height: 12),
                    Wrap(spacing: 6, runSpacing: 6, children: _model.interests.map((interest) =>
                      Chip(label: Text(_interestLabel(interest), style: theme.bodySmall),
                        backgroundColor: theme.primaryBackground, side: BorderSide(color: theme.alternate),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: VisualDensity.compact,
                      )).toList()),
                  ]),
                ),
                const SizedBox(height: 13),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 19),
                  decoration: BoxDecoration(
                    color: theme.secondaryBackground,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: theme.alternate),
                  ),
                  child: Column(children: [
                    Icon(Icons.lock_outline_rounded, color: theme.primaryText, size: 26),
                    const SizedBox(height: 8),
                    Text('Your next discoveries await', style: theme.titleMedium.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text('Unlock the remaining stops, Google Maps routes and your complete PDF guide.',
                      textAlign: TextAlign.center, style: theme.bodySmall.copyWith(color: theme.secondaryText)),
                  ]),
                ),
                const SizedBox(height: 16),
                Text('UNLOCK YOUR COMPLETE TRIP', style: theme.titleSmall.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  decoration: BoxDecoration(
                    color: theme.secondaryBackground,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: theme.alternate),
                  ),
                  child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('One personalized city trip', style: theme.titleSmall.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 3),
                      Text('One-time purchase · No subscription', style: theme.bodySmall.copyWith(color: theme.secondaryText)),
                    ])),
                    Text(_oneTripProduct?.price ?? r'$2.49', style: theme.titleLarge.copyWith(fontWeight: FontWeight.w800)),
                  ]),
                ),
                const SizedBox(height: 14),
                SizedBox(height: 54, child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.primary, foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                  onPressed: _purchaseInProgress ? null : () async {
                    final product = _oneTripProduct;
                    if (!_storeAvailable || product == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('App Store purchase is not available yet. Please try again.')),
                      );
                      return;
                    }
                    _purchaseRequested = true;
                    _pendingPurchasedItinerary = itinerary;
                    _pendingPurchasedCity = city;
                    setSheetState(() => _purchaseInProgress = true);
                    if (mounted) setState(() => _purchaseInProgress = true);
                    final started = await _iap.buyConsumable(
                      purchaseParam: PurchaseParam(productDetails: product),
                    );
                    if (!started && mounted) {
                      _purchaseRequested = false;
                      _pendingPurchasedItinerary = null;
                      _pendingPurchasedCity = null;
                      setState(() => _purchaseInProgress = false);
                      setSheetState(() => _purchaseInProgress = false);
                    }
                  },
                  child: _purchaseInProgress
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Text('Unlock My Trip · ${_oneTripProduct?.price ?? r'$2.49'}', style: const TextStyle(fontWeight: FontWeight.w700)))),
                const SizedBox(height: 8),
                Text('Payment is processed securely by the App Store.',
                  textAlign: TextAlign.center,
                  style: theme.bodySmall.copyWith(color: theme.secondaryText)),
              ],
            ),
          ),
        ),
      ),
      ),
    );
    // Successful StoreKit purchase is handled by _handlePurchaseUpdates.
  }

  Widget _testPackageTile({
    required FlutterFlowTheme theme,
    required String title,
    required String price,
    required String description,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.secondaryBackground,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? theme.primary : theme.alternate,
            width: selected ? 2 : 1)),
        child: Row(children: [
          Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
            color: selected ? theme.primary : theme.secondaryText),
          const SizedBox(width: 10),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: theme.bodyLarge.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(description, style: theme.bodySmall),
            ])),
          const SizedBox(width: 8),
          Text(price, style: theme.titleMedium.copyWith(fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('Plan your city days'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const SavedTripsPage()),
                    ),
                    icon: const Icon(Icons.bookmarks_outlined),
                    label: const Text('My Trips / History'),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Choose what you love and we'll shape the days around you.",
                    style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                          color: FlutterFlowTheme.of(context).secondaryText,
                        ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Popular Cities'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: popularCities
                        .map((c) => _choiceChip(c, _model.city == c, () {
                              setState(() {
                                _model.city = c;
                                _customCityController.clear();
                              });
                            }))
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: _sectionTitle('Beyond the Tourist Trail')),
                      TextButton(
                        onPressed: () => setState(
                          () => _showAllHiddenGems = !_showAllHiddenGems,
                        ),
                        style: TextButton.styleFrom(
                          foregroundColor: FlutterFlowTheme.of(context).tertiary,
                        ),
                        child: Text(_showAllHiddenGems ? 'Show less' : 'Show all'),
                      ),
                    ],
                  ),
                  Text(
                    'Explore smaller, less touristy cities with authentic local character.',
                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                      color: FlutterFlowTheme.of(context).secondaryText,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: (_showAllHiddenGems
                            ? hiddenGemCities
                            : hiddenGemCities.take(8))
                        .map((c) => _choiceChip(c, _model.city == c, () {
                              setState(() {
                                _model.city = c;
                                _customCityController.clear();
                              });
                            }))
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                  _sectionTitle('Enter Any City'),
                  TextField(
                    controller: _customCityController,
                    focusNode: _customCityFocusNode,
                    textCapitalization: TextCapitalization.words,
                    decoration: InputDecoration(
                      hintText: 'Type a city, e.g. Oslo',
                      prefixIcon: const Icon(Icons.search_rounded),
                      filled: true,
                      fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide(color: FlutterFlowTheme.of(context).tertiary, width: 1.5),
                      ),
                    ),
                    onChanged: (value) {
                      final city = value.trim();
                      setState(() => _model.city = city);
                    },
                    onSubmitted: (value) {
                      final city = value.trim();
                      setState(() => _model.city = city);
                    },
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('How many days?'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: List.generate(5, (index) {
                      final day = index + 1;
                      return _choiceChip(
                        '$day ${day == 1 ? 'Day' : 'Days'}',
                        _model.days == day,
                        () => setState(() => _model.days = day),
                      );
                    }),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle("What's your vibe?"),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: interestOptions.map((interest) {
                      final selected = _model.interests.contains(interest);
                      return FilterChip(
                        label: Text(_interestLabel(interest)),
                        selected: selected,
                        showCheckmark: true,
                        checkmarkColor: FlutterFlowTheme.of(context).onPrimary,
                        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
                        selectedColor: FlutterFlowTheme.of(context).primary,
                        side: BorderSide.none,
                        labelStyle: TextStyle(
                          color: selected ? FlutterFlowTheme.of(context).onPrimary : FlutterFlowTheme.of(context).primaryText,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                        ),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        onSelected: (value) {
                          setState(() {
                            if (value) {
                              if (!_model.interests.contains(interest)) {
                                _model.interests.add(interest);
                              }
                            } else {
                              _model.interests.remove(interest);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Local Gems: genuinely non-touristy local places, not famous attractions. Hiking & Nature: trails, nature walks and scenery with difficulty, distance and access information. Local Markets: optional nearby grocery stores, produce markets and supermarkets (not sightseeing stops).',
                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                      color: FlutterFlowTheme.of(context).secondaryText,
                    ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Food Preferences'),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: foodPreferenceOptions
                        .map((preference) => _choiceChip(
                              preference,
                              _foodPreference == preference,
                              () => setState(() => _foodPreference = preference),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Vegetarian excludes meat and fish. Vegan excludes all animal products, including dairy, eggs and honey. Always verify ingredients with the restaurant.',
                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                      color: FlutterFlowTheme.of(context).secondaryText,
                    ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Getting Around'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: transportOptions
                        .map((transport) => _choiceChip(
                              transport,
                              _model.gettingAround == transport,
                              () => setState(() => _model.gettingAround = transport),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Preferred Language'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: languageOptions
                        .map((language) => _choiceChip(
                              language,
                              _model.language == language,
                              () => setState(() => _model.language = language),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 36),
                  SizedBox(
                    height: 54,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: FlutterFlowTheme.of(context).primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                      onPressed: _model.isLoading == true ? null : _createTrip,
                      icon: _model.isLoading == true
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.auto_awesome_rounded),
                      label: Text(_model.isLoading == true
                          ? 'Creating your trip...'
                          : 'Create My Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
