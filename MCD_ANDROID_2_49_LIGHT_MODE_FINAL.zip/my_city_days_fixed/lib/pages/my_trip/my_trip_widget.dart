import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/trip_setup/trip_setup_widget.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';
import '/utils/pdf_download.dart';
import '/utils/trip_history_store.dart';
import 'my_trip_model.dart';
export 'my_trip_model.dart';

class MyTripWidget extends StatefulWidget {
  const MyTripWidget({super.key, required this.itineraryId, this.city, this.travelMode});

  final String? itineraryId;
  final String? city;
  final String? travelMode;

  static String routeName = 'MyTrip';
  static String routePath = '/myTrip';

  @override
  State<MyTripWidget> createState() => _MyTripWidgetState();
}

class _MyTripWidgetState extends State<MyTripWidget> {
  late MyTripModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  final Map<String, Map<String, dynamic>> _placePhotos = {};
  bool _photosLoading = false;

  String _photoStopName(String rawLine) {
    final match = RegExp(r'^\s*\d{1,2}[.)]\s+(.+)$').firstMatch(rawLine);
    if (match == null) return '';
    var name = match.group(1)!.replaceAll('**', '').trim();
    for (final separator in [' — ', ' – ', ' - ', '：', ': ']) {
      if (name.contains(separator)) {
        name = name.split(separator).first.trim();
        break;
      }
    }
    return name;
  }

  List<String> _selectPhotoStops(String itinerary) {
    final result = <String>[];
    var perDay = 0;
    for (final raw in itinerary.split('\n')) {
      final line = raw.trim();
      if (RegExp(r'^(DAY|ДЕНЬ|GÜN|DÍA|JOUR)\s+\d+', caseSensitive: false)
          .hasMatch(line)) perDay = 0;
      final name = _photoStopName(line);
      if (name.isEmpty || name.length < 4 || name.length > 90 ||
          perDay >= 3 || result.length >= 12 || result.contains(name)) continue;
      result.add(name);
      perDay++;
    }
    return result;
  }

  Future<void> _loadPlacePhotos() async {
    final city = (widget.city ?? '').trim();
    if (city.isEmpty) return;
    final stops = _selectPhotoStops(widget.itineraryId ?? '');
    if (stops.isEmpty) return;
    setState(() => _photosLoading = true);
    for (final place in stops) {
      if (!mounted) break;
      try {
        final response = await GetPlacePhotoCall.call(city: city, place: place);
        if (!mounted || !response.succeeded) continue;
        final url = GetPlacePhotoCall.photoUrl(response.jsonBody);
        if (url == null || !url.startsWith('https://')) continue;
        setState(() => _placePhotos[place] = {
          'url': url,
          'authors': GetPlacePhotoCall.attributions(response.jsonBody),
        });
      } catch (_) {
        // Missing photos never prevent itinerary, map or PDF from working.
      }
    }
    if (mounted) setState(() => _photosLoading = false);
  }

  Widget _photoForStop(String name) {
    final photo = _placePhotos[name];
    if (photo == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              photo['url'] as String,
              width: double.infinity,
              height: 215,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
          for (final author in (photo['authors'] as List).whereType<Map>())
            InkWell(
              onTap: () {
                final uri = Uri.tryParse((author['uri'] ?? '').toString());
                if (uri != null && uri.scheme == 'https') {
                  launchUrl(uri, mode: LaunchMode.externalApplication);
                }
              },
              child: Text(
                'Photo: ${author['displayName'] ?? 'Google Maps contributor'}',
                style: const TextStyle(
                  fontSize: 11,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
        ],
      ),
    );
  }



  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyTripModel());
    _loadPlacePhotos();
    if ((widget.itineraryId ?? '').trim().isNotEmpty) {
      TripHistoryStore.save(city: widget.city ?? 'My Trip', itinerary: widget.itineraryId!, travelMode: widget.travelMode).catchError((Object _) {});
    }
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  // PDF photos are fetched only for this export, not persisted or cached.
  // Use the existing Places Edge Function for every numbered sightseeing stop.
  Future<Map<String, Map<String, dynamic>>> _pdfPhotos(String itinerary) async {
    final city = (widget.city ?? '').trim();
    if (city.isEmpty) return {};
    final result = <String, Map<String, dynamic>>{};
    final names = <String>[];
    for (final rawLine in itinerary.split('\n')) {
      final name = _photoStopName(rawLine.trim());
      if (name.isNotEmpty && !names.contains(name)) names.add(name);
    }
    for (final name in names) {
      try {
        final existing = _placePhotos[name];
        String? url = existing?['url'] as String?;
        List<dynamic> authors = (existing?['authors'] as List?) ?? [];
        if (url == null || !url.startsWith('https://')) {
          final response = await GetPlacePhotoCall.call(city: city, place: name)
              .timeout(const Duration(seconds: 12));
          if (!response.succeeded) continue;
          url = GetPlacePhotoCall.photoUrl(response.jsonBody);
          authors = GetPlacePhotoCall.attributions(response.jsonBody);
        }
        if (url == null || !url.startsWith('https://')) continue;
        final imageResponse = await http.get(Uri.parse(url))
            .timeout(const Duration(seconds: 12));
        if (imageResponse.statusCode != 200 ||
            !imageResponse.headers['content-type'].toString().startsWith('image/') ||
            imageResponse.bodyBytes.length > 8000000) continue;
        result[name] = {
          'image': pw.MemoryImage(imageResponse.bodyBytes),
          'authors': authors,
        };
      } catch (_) {
        // Missing or expired photos must never prevent a PDF download.
      }
    }
    return result;
  }

  Future<void> _downloadGuide(String itinerary) async {
    try {
      // Noto Sans supports Latin, Turkish and Cyrillic text.
      // Fonts are loaded only when the user requests a PDF.
      final hasCjk = RegExp(r'[\u3400-\u9FFF]').hasMatch(itinerary);
      final regularFont = hasCjk
          ? await PdfGoogleFonts.notoSansSCRegular()
          : await PdfGoogleFonts.notoSansRegular();
      final boldFont = hasCjk
          ? await PdfGoogleFonts.notoSansSCBold()
          : await PdfGoogleFonts.notoSansBold();

      final pdfPhotos = await _pdfPhotos(itinerary);

      final pdf = pw.Document(
        title: 'My City Days Travel Guide',
        author: 'My City Days',
        theme: pw.ThemeData.withFont(
          base: regularFont,
          bold: boldFont,
        ),
      );

      final paragraphs = itinerary
          .split('\n')
          .map((line) => line.trim())
          .where((line) => line.isNotEmpty)
          .toList();

      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.fromLTRB(42, 44, 42, 44),
          header: (context) => pw.Container(
            padding: const pw.EdgeInsets.only(bottom: 12),
            decoration: const pw.BoxDecoration(
              border: pw.Border(
                bottom: pw.BorderSide(width: 0.5),
              ),
            ),
            child: pw.Text(
              'MY CITY DAYS',
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ),
          build: (context) => [
            pw.SizedBox(height: 22),
            pw.Text(
              (widget.city?.trim().isNotEmpty == true ? widget.city!.trim() : 'Your Personal Travel Guide'),
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 26,
              ),
            ),
            pw.SizedBox(height: 6),
            pw.Text(
              'MY CITY DAYS  •  PERSONAL TRAVEL GUIDE',
              style: pw.TextStyle(
                font: regularFont,
                fontSize: 12,
              ),
            ),
            pw.SizedBox(height: 20),
            pw.Divider(),
            pw.SizedBox(height: 14),
            ...paragraphs.map((line) {
              final lower = line.toLowerCase();
              final isHeading = RegExp(r'^\d+[.)]\s+').hasMatch(line) ||
                  RegExp(r'^stop\s+\d+', caseSensitive: false).hasMatch(line) ||
                  lower.startsWith('day ') ||
                  lower.startsWith('good to know') ||
                  lower.startsWith('день ') ||
                  lower.startsWith('полезно знать') ||
                  lower.startsWith('gün ') ||
                  lower.startsWith('bilmeniz') ||
                  line.startsWith('第') ||
                  line.startsWith('实用') ||
                  line.startsWith('交通') ||
                  line.startsWith('当地');

              final stopName = _photoStopName(line);
              final photo = pdfPhotos[stopName];
              final authors = (photo?['authors'] as List?) ?? [];
              return pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Padding(
                    padding: const pw.EdgeInsets.only(bottom: 7),
                    child: pw.Text(
                      line,
                      style: pw.TextStyle(
                        font: isHeading ? boldFont : regularFont,
                        fontSize: isHeading ? 13 : 10.5,
                        lineSpacing: 3,
                      ),
                    ),
                  ),
                  if (photo != null) ...[
                    pw.Image(
                      photo['image'] as pw.MemoryImage,
                      width: 300,
                      height: 170,
                      fit: pw.BoxFit.cover,
                    ),
                    pw.SizedBox(height: 3),
                    for (final author in authors.whereType<Map>())
                      pw.Text(
                        'Photo: ${author['displayName'] ?? 'Google Maps contributor'}'
                        '${(author['uri'] ?? '').toString().isNotEmpty ? ' • ${author['uri']}' : ''}',
                        style: pw.TextStyle(font: regularFont, fontSize: 7),
                      ),
                    pw.SizedBox(height: 12),
                  ],
                ],
              );
            }),
            pw.SizedBox(height: 22),
            pw.Divider(),
            pw.Text('Travel Information Disclaimer',
                style: pw.TextStyle(font: boldFont, fontSize: 10)),
            pw.SizedBox(height: 6),
            pw.Text('Prices, admission fees, opening hours and availability may change. '
                'My City Days provides informational recommendations and cannot guarantee '
                'that all details are current. Verify information with official websites '
                'or the venue before your visit.',
                style: pw.TextStyle(font: regularFont, fontSize: 9)),
          ],
          footer: (context) => pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Text(
              'Page ${context.pageNumber} of ${context.pagesCount}',
              style: pw.TextStyle(
                font: regularFont,
                fontSize: 8.5,
              ),
            ),
          ),
        ),
      );

      final bytes = await pdf.save();

      // On web, download directly instead of opening the heavy share/print flow
      // that was causing Chrome RESULT_CODE_HUNG.
      // On iOS/Android, the helper falls back to the native share sheet.
      await savePdfBytes(
        bytes,
        'my-city-days-${(widget.city ?? 'travel-guide').toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-')}.pdf',
      );
      await TripHistoryStore.recordDownload(
        city: widget.city ?? 'My Trip', itinerary: itinerary);

    } catch (e) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not create PDF: $e'),
        ),
      );
    }
  }

  Map<int, List<String>> _extractDayStops(String itinerary) {
    final days = <int, List<String>>{};
    var currentDay = 1;
    days[currentDay] = <String>[];

    final dayPatterns = <RegExp>[
      RegExp(r'^\s*Day\s+(\d+)', caseSensitive: false),
      RegExp(r'^\s*День\s+(\d+)', caseSensitive: false),
      RegExp(r'^\s*(\d+)\.\s*Gün', caseSensitive: false),
      RegExp(r'^\s*Gün\s+(\d+)', caseSensitive: false),
      RegExp(r'^\s*第\s*(\d+)\s*天'),
    ];
    final stopPattern = RegExp(r'^\s*\d+[\)\.、]\s*(.+)$');

    for (final rawLine in itinerary.split('\n')) {
      final line = rawLine.trim();
      if (line.isEmpty) continue;

      var foundDay = false;
      for (final pattern in dayPatterns) {
        final match = pattern.firstMatch(line);
        if (match != null) {
          currentDay = int.tryParse(match.group(1) ?? '') ?? currentDay;
          days.putIfAbsent(currentDay, () => <String>[]);
          foundDay = true;
          break;
        }
      }
      if (foundDay) continue;

      final stopMatch = stopPattern.firstMatch(line);
      if (stopMatch == null) continue;
      final rawStop = (stopMatch.group(1) ?? '').trim();

      // The model is instructed not to number food recommendations, but keep
      // a defensive filter here too. Check the FULL numbered line before
      // trimming it to the place name so a named restaurant such as
      // "Marina Deli — lunch..." is still recognized as a meal stop.
      final lowerRawStop = rawStop.toLowerCase();
      final looksLikeFoodStop = RegExp(
        r'\b(breakfast|brunch|lunch|dinner|coffee|cafe|café|restaurant|restaurants|deli|bakery|bar|food|eat|cuisine|dish|order|reservation|price level|завтрак|обед|ужин|кофе|кафе|ресторан|еда|кухня|заказать|бронирован|kahvaltı|öğle|ogle|akşam|aksam|yemek|kafe|restoran|mutfak|rezervasyon|早餐|早午餐|午餐|晚餐|咖啡|咖啡馆|餐厅|美食|用餐|预订)\b',
        caseSensitive: false,
      ).hasMatch(lowerRawStop);
      if (looksLikeFoodStop) continue;

      var name = rawStop;

      // Keep only the place name; generated guides normally separate details
      // with an em dash, en dash, hyphen, colon, or Chinese full-width colon.
      for (final separator in [' — ', ' – ', ' - ', '：', ': ']) {
        if (name.contains(separator)) {
          name = name.split(separator).first.trim();
          break;
        }
      }
      name = name.replaceAll(RegExp(r'\s*\([^)]*(?:min|分钟|分钟步程|分钟车程)[^)]*\)\s*$', caseSensitive: false), '');

      // Day routes should contain sightseeing/activity POIs only. Food remains
      // in the written guide but is deliberately excluded from Google Maps.
      final lowerName = name.toLowerCase();
      final looksLikeMeal = RegExp(
        r'^(breakfast|brunch|lunch|dinner|coffee|cafe|café|restaurant|завтрак|обед|ужин|кофе|кафе|ресторан|kahvaltı|öğle|ogle|akşam|aksam|yemek|kafe|restoran|早餐|早午餐|午餐|晚餐|咖啡|咖啡馆|餐厅)',
        caseSensitive: false,
      ).hasMatch(lowerName);
      // A numbered paragraph is not necessarily a mappable point of interest.
      // Exclude instructions, vague alternatives and headings from navigation only.
      final vagueStop = RegExp(
        r'^(return|head back|go back|walk back|continue|optional|short |free time|explore |stroll |wander |transfer|take |ride |drive |arrive |depart |end of|start of|break |rest |nearby |around |route |\d+\s+stops?\b|вернитесь|возвращение|прогулка по|пройдите|переезд|прогуляйтесь|опционально|по желанию|dönüş|geri dön|yürüyüş|isteğe bağlı)\b',
        caseSensitive: false,
      ).hasMatch(lowerName);
      final unclearStop = RegExp(
        r'\b(or similar|or nearby|or another|of your choice|if time allows|as desired|optional stop|small galleries|neighborhood park|local streets|nearby park)\b',
        caseSensitive: false,
      ).hasMatch(lowerName);
      if (!looksLikeMeal && !vagueStop && !unclearStop &&
          name.length >= 4 && name.length <= 90) {
        final dayStops = days.putIfAbsent(currentDay, () => <String>[]);
        if (!dayStops.contains(name)) dayStops.add(name);
      }
    }

    days.removeWhere((_, stops) => stops.length < 2);
    return days;
  }

  // Navigation is independent of Google Places resolution. Mai's ordered
  // sightseeing stops remain in the route, including names not in Places.
  Future<void> _openDayMaps(int day, List<String> stops) async {
    if (stops.isEmpty) return;
    final city = (widget.city ?? '').trim();
    final selectedMode =
        (widget.travelMode ?? 'Walking + Public Transit').toLowerCase();
    final mode = selectedMode.contains('car') || selectedMode.contains('ride')
        ? 'driving'
        : selectedMode.contains('transit') && !selectedMode.contains('walk')
            ? 'transit'
            : 'walking';

    // Keep every stop, in Mai's original order. City is only a search hint;
    // no network verification is required to open Maps.
    final points = stops
        .map((stop) => city.isEmpty ? stop.trim() : '${stop.trim()}, $city')
        .where((stop) => stop.isNotEmpty)
        .toList();
    if (points.isEmpty) return;

    Uri makeRoute(List<String> segment) {
      if (segment.length == 1) {
        return Uri.https('www.google.com', '/maps/search/', {
          'api': '1', 'query': segment.first,
        });
      }
      final params = <String, String>{
        'api': '1',
        'origin': segment.first,
        'destination': segment.last,
        'travelmode': mode,
      };
      if (segment.length > 2) {
        params['waypoints'] = segment.sublist(1, segment.length - 1).join('|');
      }
      return Uri.https('www.google.com', '/maps/dir/', params);
    }

    Future<void> openRoute(Uri uri) async {
      await TripHistoryStore.recordMap(
        city: widget.city ?? 'My Trip',
        itinerary: (widget.itineraryId ?? '').trim(),
        day: day,
        url: uri.toString(),
      );
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open Google Maps.')),
        );
      }
    }

    // Open normal day routes immediately. Google Maps URL waypoint support
    // varies by device; longer routes are split without dropping any stop.
    final fullUri = makeRoute(points);
    if (points.length <= 9) {
      await openRoute(fullUri);
      return;
    }

    // Consecutive segments overlap at their boundary stop, preserving
    // the complete ordered itinerary without silently removing places.
    final segments = <List<String>>[];
    for (var start = 0; start < points.length - 1; start += 8) {
      final finish = (start + 9 < points.length) ? start + 9 : points.length;
      segments.add(points.sublist(start, finish));
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Day $day — Google Maps'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${points.length} stops, in Mai\'s order.'),
                const SizedBox(height: 8),
                const Text('This day has many stops. Open consecutive parts '
                    'to keep every place in the route:'),
                const SizedBox(height: 8),
                for (var i = 0; i < segments.length; i++)
                  TextButton(
                    onPressed: () => openRoute(makeRoute(segments[i])),
                    child: Text('Part ${i + 1}: '
                        '${segments[i].first.split(', ').first} → '
                        '${segments[i].last.split(', ').first}'),
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final itinerary = (widget.itineraryId ?? '').trim();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('My Trip'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    (widget.city?.trim().isNotEmpty == true ? widget.city!.trim() : 'Your Trip'),
                    style: FlutterFlowTheme.of(context).headlineMedium.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 18),
                  if (_photosLoading) const LinearProgressIndicator(),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).alternate,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: itinerary.isEmpty
                          ? [const Text('Loading your trip...')]
                          : itinerary.split('\n').where((line) => line.trim().isNotEmpty).map((line) {
                              final cleaned = line.trim();
                              final isDay = RegExp(r'^(DAY\s+\d+|ДЕНЬ\s+\d+|GÜN\s+\d+|DÍA\s+\d+|JOUR\s+\d+|第[一二三四五六七八九十0-9]+天)', caseSensitive: false).hasMatch(cleaned);
                              final isStop = RegExp(r'^(STOP\s+\d+|\d+[.)]\s+)', caseSensitive: false).hasMatch(cleaned);
                              return Padding(
                                padding: EdgeInsets.only(top: isDay ? 18 : (isStop ? 12 : 4), bottom: 4),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SelectableText(
                                  cleaned,
                                  style: (isDay
                                      ? FlutterFlowTheme.of(context).titleLarge
                                      : isStop
                                          ? FlutterFlowTheme.of(context).titleMedium
                                          : FlutterFlowTheme.of(context).bodyLarge).copyWith(
                                    fontWeight: (isDay || isStop) ? FontWeight.w800 : FontWeight.w400,
                                    height: 1.5,
                                  ),
                                    ),
                                    _photoForStop(_photoStopName(cleaned)),
                                  ],
                                ),
                              );
                            }).toList(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text('Travel Information Disclaimer',
                      style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                        fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('Prices, admission fees, opening hours and availability may change. '
                      'My City Days cannot guarantee that all details are current. '
                      'Please verify the latest information with official websites '
                      'or the venue before your visit.',
                      style: FlutterFlowTheme.of(context).bodySmall),
                  const SizedBox(height: 22),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                      builder: (_) => const SavedTripsPage(),
                    )),
                    icon: const Icon(Icons.bookmarks_outlined),
                    label: const Text('My Trips / History'),
                  ),
                  const SizedBox(height: 12),
                  ..._extractDayStops(itinerary).entries.expand((entry) => [
                        OutlinedButton.icon(
                          onPressed: () => _openDayMaps(entry.key, entry.value),
                          icon: const Icon(Icons.map_outlined),
                          label: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            child: Text('Open Day ${entry.key} in Maps'),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ]),
                  FilledButton.icon(
                    onPressed: itinerary.isEmpty
                        ? null
                        : () => _downloadGuide(itinerary),
                    icon: const Icon(Icons.picture_as_pdf_rounded),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Download My Guide (PDF)'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () =>
                        context.goNamed(TripSetupWidget.routeName),
                    icon: const Icon(Icons.add_location_alt_outlined),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Plan Another Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


/// Local history viewer for the closed test. Cloud history comes next.
class SavedTripsPage extends StatelessWidget {
  const SavedTripsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Trips / History')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: TripHistoryStore.load(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final trips = snapshot.data!;
          if (trips.isEmpty) return const Center(child: Text('No saved trips yet.'));
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: trips.length,
            separatorBuilder: (_, __) => const Divider(),
            itemBuilder: (context, index) {
              final trip = trips[index];
              final city = trip['city'] as String? ?? 'My Trip';
              final itinerary = trip['itinerary'] as String? ?? '';
              final mapUrls = Map<String, dynamic>.from(trip['mapUrls'] as Map? ?? {});
              final downloadCount = (trip['pdfExports'] as List?)?.length ?? 0;
              return ListTile(
                leading: const Icon(Icons.place_outlined),
                title: Text(city, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text((trip['createdAt'] as String? ?? '').split('T').first),
                    if (downloadCount > 0) Text('PDF exports: $downloadCount'),
                    if (mapUrls.isNotEmpty)
                      Wrap(spacing: 6, children: mapUrls.entries.map((entry) =>
                        TextButton.icon(
                          onPressed: () async {
                            final link = Uri.tryParse(entry.value.toString());
                            if (link != null && link.scheme == 'https' &&
                                link.host == 'www.google.com') {
                              await launchUrl(link, mode: LaunchMode.externalApplication);
                            }
                          },
                          icon: const Icon(Icons.map_outlined, size: 16),
                          label: Text('Day ${entry.key} map'),
                        ),
                      ).toList()),
                  ],
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                  builder: (_) => MyTripWidget(itineraryId: itinerary, city: city, travelMode: trip['travelMode'] as String?),
                )),
              );
            },
          );
        },
      ),
    );
  }
}
