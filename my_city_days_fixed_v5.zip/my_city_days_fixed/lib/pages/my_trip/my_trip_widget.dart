import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/trip_setup/trip_setup_widget.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '/utils/pdf_download.dart';
import 'my_trip_model.dart';
export 'my_trip_model.dart';

class MyTripWidget extends StatefulWidget {
  const MyTripWidget({super.key, required this.itineraryId});

  final String? itineraryId;

  static String routeName = 'MyTrip';
  static String routePath = '/myTrip';

  @override
  State<MyTripWidget> createState() => _MyTripWidgetState();
}

class _MyTripWidgetState extends State<MyTripWidget> {
  late MyTripModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyTripModel());
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  Future<void> _downloadGuide(String itinerary) async {
    try {
      // Noto Sans supports Latin, Turkish and Cyrillic text.
      // Fonts are loaded only when the user requests a PDF.
      final regularFont = await PdfGoogleFonts.notoSansRegular();
      final boldFont = await PdfGoogleFonts.notoSansBold();

      final pdf = pw.Document(
        title: 'My City Days Travel Guide',
        author: 'My City Days',
        theme: pw.ThemeData.withFont(
          base: regularFont,
          bold: boldFont,
        ),
      );

      final paragraphs = itinerary
          .split('\n')
          .map((line) => line.trim())
          .where((line) => line.isNotEmpty)
          .toList();

      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.fromLTRB(42, 44, 42, 44),
          header: (context) => pw.Container(
            padding: const pw.EdgeInsets.only(bottom: 12),
            decoration: const pw.BoxDecoration(
              border: pw.Border(
                bottom: pw.BorderSide(width: 0.5),
              ),
            ),
            child: pw.Text(
              'MY CITY DAYS',
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ),
          build: (context) => [
            pw.SizedBox(height: 22),
            pw.Text(
              'Your Personal Travel Guide',
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 26,
              ),
            ),
            pw.SizedBox(height: 6),
            pw.Text(
              'Created especially for your trip',
              style: pw.TextStyle(
                font: regularFont,
                fontSize: 12,
              ),
            ),
            pw.SizedBox(height: 20),
            pw.Divider(),
            pw.SizedBox(height: 14),
            ...paragraphs.map((line) {
              final lower = line.toLowerCase();
              final isHeading = lower.startsWith('day ') ||
                  lower.startsWith('good to know') ||
                  lower.startsWith('день ') ||
                  lower.startsWith('полезно знать') ||
                  lower.startsWith('gün ') ||
                  lower.startsWith('bilmeniz');

              return pw.Padding(
                padding: const pw.EdgeInsets.only(bottom: 7),
                child: pw.Text(
                  line,
                  style: pw.TextStyle(
                    font: isHeading ? boldFont : regularFont,
                    fontSize: isHeading ? 13 : 10.5,
                    lineSpacing: 3,
                  ),
                ),
              );
            }),
          ],
          footer: (context) => pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Text(
              'Page ${context.pageNumber} of ${context.pagesCount}',
              style: pw.TextStyle(
                font: regularFont,
                fontSize: 8.5,
              ),
            ),
          ),
        ),
      );

      final bytes = await pdf.save();

      // On web, download directly instead of opening the heavy share/print flow
      // that was causing Chrome RESULT_CODE_HUNG.
      // On iOS/Android, the helper falls back to the native share sheet.
      await savePdfBytes(
        bytes,
        'my-city-days-guide.pdf',
      );
    } catch (e) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not create PDF: $e'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final itinerary = (widget.itineraryId ?? '').trim();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('My Trip'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Your AI itinerary',
                    style: FlutterFlowTheme.of(context).headlineMedium.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).alternate,
                      ),
                    ),
                    child: SelectableText(
                      itinerary.isEmpty ? 'Loading your trip...' : itinerary,
                      style: FlutterFlowTheme.of(context).bodyLarge.copyWith(
                            height: 1.55,
                          ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: itinerary.isEmpty
                        ? null
                        : () => _downloadGuide(itinerary),
                    icon: const Icon(Icons.picture_as_pdf_rounded),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Download My Guide (PDF)'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () =>
                        context.goNamed(TripSetupWidget.routeName),
                    icon: const Icon(Icons.add_location_alt_outlined),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Plan Another Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
