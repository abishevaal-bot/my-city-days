import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/trip_setup/trip_setup_widget.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';
import '/utils/pdf_download.dart';
import 'my_trip_model.dart';
export 'my_trip_model.dart';

class MyTripWidget extends StatefulWidget {
  const MyTripWidget({super.key, required this.itineraryId, this.city});

  final String? itineraryId;
  final String? city;

  static String routeName = 'MyTrip';
  static String routePath = '/myTrip';

  @override
  State<MyTripWidget> createState() => _MyTripWidgetState();
}

class _MyTripWidgetState extends State<MyTripWidget> {
  late MyTripModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyTripModel());
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  Future<void> _downloadGuide(String itinerary) async {
    try {
      // Noto Sans supports Latin, Turkish and Cyrillic text.
      // Fonts are loaded only when the user requests a PDF.
      final hasCjk = RegExp(r'[\u3400-\u9FFF]').hasMatch(itinerary);
      final regularFont = hasCjk
          ? await PdfGoogleFonts.notoSansSCRegular()
          : await PdfGoogleFonts.notoSansRegular();
      final boldFont = hasCjk
          ? await PdfGoogleFonts.notoSansSCBold()
          : await PdfGoogleFonts.notoSansBold();

      final pdf = pw.Document(
        title: 'My City Days Travel Guide',
        author: 'My City Days',
        theme: pw.ThemeData.withFont(
          base: regularFont,
          bold: boldFont,
        ),
      );

      final paragraphs = itinerary
          .split('\n')
          .map((line) => line.trim())
          .where((line) => line.isNotEmpty)
          .toList();

      pdf.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.fromLTRB(42, 44, 42, 44),
          header: (context) => pw.Container(
            padding: const pw.EdgeInsets.only(bottom: 12),
            decoration: const pw.BoxDecoration(
              border: pw.Border(
                bottom: pw.BorderSide(width: 0.5),
              ),
            ),
            child: pw.Text(
              'MY CITY DAYS',
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ),
          build: (context) => [
            pw.SizedBox(height: 22),
            pw.Text(
              'Your Personal Travel Guide',
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 26,
              ),
            ),
            pw.SizedBox(height: 6),
            pw.Text(
              'Created especially for your trip',
              style: pw.TextStyle(
                font: regularFont,
                fontSize: 12,
              ),
            ),
            pw.SizedBox(height: 20),
            pw.Divider(),
            pw.SizedBox(height: 14),
            ...paragraphs.map((line) {
              final lower = line.toLowerCase();
              final isHeading = lower.startsWith('day ') ||
                  lower.startsWith('good to know') ||
                  lower.startsWith('день ') ||
                  lower.startsWith('полезно знать') ||
                  lower.startsWith('gün ') ||
                  lower.startsWith('bilmeniz') ||
                  line.startsWith('第') ||
                  line.startsWith('实用') ||
                  line.startsWith('交通') ||
                  line.startsWith('当地');

              return pw.Padding(
                padding: const pw.EdgeInsets.only(bottom: 7),
                child: pw.Text(
                  line,
                  style: pw.TextStyle(
                    font: isHeading ? boldFont : regularFont,
                    fontSize: isHeading ? 13 : 10.5,
                    lineSpacing: 3,
                  ),
                ),
              );
            }),
          ],
          footer: (context) => pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Text(
              'Page ${context.pageNumber} of ${context.pagesCount}',
              style: pw.TextStyle(
                font: regularFont,
                fontSize: 8.5,
              ),
            ),
          ),
        ),
      );

      final bytes = await pdf.save();

      // On web, download directly instead of opening the heavy share/print flow
      // that was causing Chrome RESULT_CODE_HUNG.
      // On iOS/Android, the helper falls back to the native share sheet.
      await savePdfBytes(
        bytes,
        'my-city-days-guide.pdf',
      );
    } catch (e) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not create PDF: $e'),
        ),
      );
    }
  }

  Map<int, List<String>> _extractDayStops(String itinerary) {
    final days = <int, List<String>>{};
    var currentDay = 1;
    days[currentDay] = <String>[];

    final dayPatterns = <RegExp>[
      RegExp(r'^\s*Day\s+(\d+)', caseSensitive: false),
      RegExp(r'^\s*День\s+(\d+)', caseSensitive: false),
      RegExp(r'^\s*(\d+)\.\s*Gün', caseSensitive: false),
      RegExp(r'^\s*Gün\s+(\d+)', caseSensitive: false),
      RegExp(r'^\s*第\s*(\d+)\s*天'),
    ];
    final stopPattern = RegExp(r'^\s*\d+[\)\.、]\s*(.+)$');

    for (final rawLine in itinerary.split('\n')) {
      final line = rawLine.trim();
      if (line.isEmpty) continue;

      var foundDay = false;
      for (final pattern in dayPatterns) {
        final match = pattern.firstMatch(line);
        if (match != null) {
          currentDay = int.tryParse(match.group(1) ?? '') ?? currentDay;
          days.putIfAbsent(currentDay, () => <String>[]);
          foundDay = true;
          break;
        }
      }
      if (foundDay) continue;

      final stopMatch = stopPattern.firstMatch(line);
      if (stopMatch == null) continue;
      var name = (stopMatch.group(1) ?? '').trim();

      // Keep only the place name; generated guides normally separate details
      // with an em dash, en dash, hyphen, colon, or Chinese full-width colon.
      for (final separator in [' — ', ' – ', ' - ', '：', ': ']) {
        if (name.contains(separator)) {
          name = name.split(separator).first.trim();
          break;
        }
      }
      name = name.replaceAll(RegExp(r'\s*\([^)]*(?:min|分钟|分钟步程|分钟车程)[^)]*\)\s*$', caseSensitive: false), '');
      if (name.isNotEmpty) days.putIfAbsent(currentDay, () => <String>[]).add(name);
    }

    days.removeWhere((_, stops) => stops.length < 2);
    return days;
  }

  Future<void> _openDayMaps(List<String> stops) async {
    if (stops.length < 2) return;

    // Anchor every generated stop to the selected trip city. This prevents
    // Google Maps from resolving generic names (for example, Chinatown)
    // to a similarly named place in another city.
    final city = (widget.city ?? '').trim();
    final mappedStops = city.isEmpty
        ? stops
        : stops.map((stop) => '$stop, $city').toList();

    final origin = Uri.encodeComponent(mappedStops.first);
    final destination = Uri.encodeComponent(mappedStops.last);
    final middle = mappedStops.length > 2
        ? mappedStops.sublist(1, mappedStops.length - 1)
        : <String>[];
    final waypoints = middle.isEmpty
        ? ''
        : '&waypoints=${middle.map(Uri.encodeComponent).join('%7C')}';
    final uri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1&origin=$origin&destination=$destination$waypoints',
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final itinerary = (widget.itineraryId ?? '').trim();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('My Trip'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Your AI itinerary',
                    style: FlutterFlowTheme.of(context).headlineMedium.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).alternate,
                      ),
                    ),
                    child: SelectableText(
                      itinerary.isEmpty ? 'Loading your trip...' : itinerary,
                      style: FlutterFlowTheme.of(context).bodyLarge.copyWith(
                            height: 1.55,
                          ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  ..._extractDayStops(itinerary).entries.expand((entry) => [
                        OutlinedButton.icon(
                          onPressed: () => _openDayMaps(entry.value),
                          icon: const Icon(Icons.map_outlined),
                          label: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            child: Text('Open Day ${entry.key} in Maps'),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ]),
                  FilledButton.icon(
                    onPressed: itinerary.isEmpty
                        ? null
                        : () => _downloadGuide(itinerary),
                    icon: const Icon(Icons.picture_as_pdf_rounded),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Download My Guide (PDF)'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () =>
                        context.goNamed(TripSetupWidget.routeName),
                    icon: const Icon(Icons.add_location_alt_outlined),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Plan Another Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
