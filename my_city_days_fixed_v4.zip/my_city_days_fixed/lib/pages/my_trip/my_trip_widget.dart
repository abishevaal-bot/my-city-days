import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/trip_setup/trip_setup_widget.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'my_trip_model.dart';
export 'my_trip_model.dart';

class MyTripWidget extends StatefulWidget {
  const MyTripWidget({super.key, required this.itineraryId});

  final String? itineraryId;

  static String routeName = 'MyTrip';
  static String routePath = '/myTrip';

  @override
  State<MyTripWidget> createState() => _MyTripWidgetState();
}

class _MyTripWidgetState extends State<MyTripWidget> {
  late MyTripModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyTripModel());
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  Future<void> _downloadGuide(String itinerary) async {
    final pdf = pw.Document(
      title: 'My City Days Travel Guide',
      author: 'My City Days',
    );

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        header: (context) => pw.Padding(
          padding: const pw.EdgeInsets.only(bottom: 14),
          child: pw.Text(
            'MY CITY DAYS',
            style: pw.TextStyle(
              fontSize: 11,
              fontWeight: pw.FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ),
        build: (context) => [
          pw.SizedBox(height: 24),
          pw.Text(
            'Your Personal Travel Guide',
            style: pw.TextStyle(
              fontSize: 28,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 8),
          pw.Text(
            'Created especially for your trip',
            style: const pw.TextStyle(fontSize: 13),
          ),
          pw.SizedBox(height: 30),
          pw.Divider(),
          pw.SizedBox(height: 18),
          pw.Text(
            itinerary,
            style: const pw.TextStyle(
              fontSize: 11.5,
              lineSpacing: 4,
            ),
          ),
        ],
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text(
            'Page ${context.pageNumber} of ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 9),
          ),
        ),
      ),
    );

    await Printing.sharePdf(
      bytes: await pdf.save(),
      filename: 'my-city-days-guide.pdf',
    );
  }

  @override
  Widget build(BuildContext context) {
    final itinerary = (widget.itineraryId ?? '').trim();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('My Trip'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Your AI itinerary',
                    style: FlutterFlowTheme.of(context).headlineMedium.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).alternate,
                      ),
                    ),
                    child: SelectableText(
                      itinerary.isEmpty ? 'Loading your trip...' : itinerary,
                      style: FlutterFlowTheme.of(context).bodyLarge.copyWith(
                            height: 1.55,
                          ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: itinerary.isEmpty
                        ? null
                        : () => _downloadGuide(itinerary),
                    icon: const Icon(Icons.picture_as_pdf_rounded),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Download My Guide (PDF)'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () =>
                        context.goNamed(TripSetupWidget.routeName),
                    icon: const Icon(Icons.add_location_alt_outlined),
                    label: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14),
                      child: Text('Plan Another Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
