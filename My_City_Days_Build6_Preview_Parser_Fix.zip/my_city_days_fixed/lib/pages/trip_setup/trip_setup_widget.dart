import 'dart:async';

import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import '/pages/my_trip/my_trip_widget.dart' show SavedTripsPage;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'trip_setup_model.dart';
export 'trip_setup_model.dart';

class TripSetupWidget extends StatefulWidget {
  const TripSetupWidget({super.key});

  static String routeName = 'TripSetup';
  static String routePath = '/tripSetup';

  @override
  State<TripSetupWidget> createState() => _TripSetupWidgetState();
}

class _TripSetupWidgetState extends State<TripSetupWidget> {
  late TripSetupModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  late final TextEditingController _customCityController;
  late final FocusNode _customCityFocusNode;
  bool _showAllHiddenGems = false;
  String _foodPreference = 'No Preference';

  static const String _oneTripProductId = 'com.abisheva.mycitydays.onetrip';
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;
  ProductDetails? _oneTripProduct;
  bool _storeAvailable = false;
  bool _purchaseInProgress = false;
  bool _purchaseRequested = false;
  bool _paywallOpen = false;

  final popularCities = const [
    'New York',
    'Paris',
    'Tokyo',
    'Rome',
    'London',
    'Barcelona',
    'Dubai',
    'Istanbul',
    'San Francisco',
    'San Diego',
  ];
  final hiddenGemCities = const [
    'Santa Barbara',
    'Savannah',
    'Portland, Maine',
    'Ljubljana',
    'Bologna',
    'Zaragoza',
    'Tbilisi',
    'Plovdiv',
    'Almaty',
    'Tashkent',
    'Samarkand',
    'Bukhara',
    'Kanazawa',
    'Fukuoka',
    'Busan',
    'Gyeongju',
    'Chengdu',
    'Chongqing',
    'Shenzhen',
  ];
  final interestOptions = const ['Food', 'Culture', 'Shopping', 'Nature', 'Local Gems', 'Local Markets'];
  final languageOptions = const ['English', 'Russian', 'Turkish', 'Simplified Chinese', 'Spanish', 'French'];
  final foodPreferenceOptions = const ['No Preference', 'Vegetarian', 'Vegan'];
  final transportOptions = const ['Walking + Public Transit', 'Rideshare', 'Car'];

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TripSetupModel());
    _customCityController = TextEditingController();
    _customCityFocusNode = FocusNode();
    _initStore();
  }

  Future<void> _initStore() async {
    if (kIsWeb) return;

    _purchaseSubscription = _iap.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: (Object error) {
        if (!mounted) return;
        setState(() => _purchaseInProgress = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Purchase error: $error')),
        );
      },
    );

    try {
      final available = await _iap.isAvailable();
      if (!mounted) return;
      if (!available) {
        setState(() => _storeAvailable = false);
        return;
      }

      final response = await _iap.queryProductDetails({_oneTripProductId});
      if (!mounted) return;
      setState(() {
        _storeAvailable = response.error == null && response.productDetails.isNotEmpty;
        _oneTripProduct = response.productDetails.isEmpty ? null : response.productDetails.first;
      });
    } catch (_) {
      if (mounted) setState(() => _storeAvailable = false);
    }
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.productID != _oneTripProductId) continue;

      if (purchase.status == PurchaseStatus.pending) {
        if (mounted) setState(() => _purchaseInProgress = true);
        continue;
      }

      if (purchase.status == PurchaseStatus.error ||
          purchase.status == PurchaseStatus.canceled) {
        if (mounted) {
          setState(() => _purchaseInProgress = false);
          if (purchase.status == PurchaseStatus.error) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(purchase.error?.message ?? 'Purchase could not be completed.')),
            );
          }
        }
        _purchaseRequested = false;
      }

      if (purchase.status == PurchaseStatus.purchased) {
        if (purchase.pendingCompletePurchase) {
          await _iap.completePurchase(purchase);
        }

        final shouldCreateTrip = _purchaseRequested;
        _purchaseRequested = false;
        if (!mounted) return;
        setState(() => _purchaseInProgress = false);

        if (shouldCreateTrip) {
          if (_paywallOpen && Navigator.of(context).canPop()) {
            Navigator.of(context).pop();
            _paywallOpen = false;
          }
          await _generateTrip();
        }
      } else if (purchase.pendingCompletePurchase) {
        await _iap.completePurchase(purchase);
      }
    }
  }

  @override
  void dispose() {
    _purchaseSubscription?.cancel();
    _customCityController.dispose();
    _customCityFocusNode.dispose();
    _model.dispose();
    super.dispose();
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(
          text,
          style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
      );

  Widget _choiceChip(String label, bool selected, VoidCallback onTap) {
    return ChoiceChip(
      label: Text(label),
      avatar: selected
          ? const Icon(Icons.check_rounded, size: 16, color: Colors.white)
          : null,
      selected: selected,
      showCheckmark: false,
      backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
      selectedColor: FlutterFlowTheme.of(context).primary,
      side: BorderSide.none,
      labelStyle: TextStyle(
        color: selected ? Colors.white : FlutterFlowTheme.of(context).primaryText,
        fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      onSelected: (_) => onTap(),
    );
  }

  Future<void> _createTrip() async {
    if (_model.isLoading == true || _purchaseInProgress) return;
    if ((_model.city ?? '').isEmpty ||
        (_model.language ?? '').isEmpty ||
        _model.interests.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose a city, interests and language.')),
      );
      return;
    }

    await _generateTrip();
  }

  Future<void> _showPaywall() async {
    final price = _oneTripProduct?.price ?? r'$8.99';

    _paywallOpen = true;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 42,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 22),
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).alternate,
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6E8DD),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.explore_rounded,
                        color: FlutterFlowTheme.of(context).primary,
                        size: 30,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Your personalized trip is ready',
                      style: FlutterFlowTheme.of(context).headlineSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Before you purchase, here’s exactly what is included in your one-time trip purchase.',
                      style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                            color: FlutterFlowTheme.of(context).secondaryText,
                            height: 1.45,
                          ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'What you’ll get',
                      style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 10),
                    _paywallFeature(Icons.route_rounded, 'Personalized day-by-day itinerary'),
                    _paywallFeature(Icons.restaurant_rounded, 'Recommendations, food spots & local gems'),
                    _paywallFeature(Icons.lightbulb_outline_rounded, 'Practical travel tips for your destination'),
                    _paywallFeature(Icons.map_rounded, 'Google Maps routes for your days'),
                    _paywallFeature(Icons.picture_as_pdf_rounded, 'Downloadable My City Days guide'),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6E8DD),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        'One-time in-app purchase · $price per trip · No subscription',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                              fontWeight: FontWeight.w700,
                              color: FlutterFlowTheme.of(context).primaryText,
                            ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('One personalized trip',
                                    style: FlutterFlowTheme.of(context).bodyLarge.copyWith(
                                          fontWeight: FontWeight.w700,
                                        )),
                                const SizedBox(height: 3),
                                Text('One-time purchase',
                                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                                          color: FlutterFlowTheme.of(context).secondaryText,
                                        )),
                              ],
                            ),
                          ),
                          Text(
                            price,
                            style: FlutterFlowTheme.of(context).titleLarge.copyWith(
                                  fontWeight: FontWeight.w800,
                                ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 56,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: FlutterFlowTheme.of(context).primary,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        onPressed: _purchaseInProgress
                            ? null
                            : () async {
                                setSheetState(() => _purchaseInProgress = true);
                                if (mounted) {
                                  setState(() => _purchaseInProgress = true);
                                }
                                Navigator.of(sheetContext).pop();
                                _paywallOpen = false;
                                if (mounted) {
                                  setState(() => _purchaseInProgress = false);
                                }
                                await _generateTrip();
                              },
                        child: _purchaseInProgress
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Create My Trip · $price',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Internal test · No payment will be charged. Tap the button to continue.',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                            color: FlutterFlowTheme.of(context).secondaryText,
                          ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
    _paywallOpen = false;
  }

  Widget _paywallFeature(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFF6E8DD),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, size: 19, color: FlutterFlowTheme.of(context).tertiary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  // Keep the AI request concise and conditional. Mai writes the guide directly
  // in the chosen language; the UI owns map links, PDF and paywall formatting.
  String _buildNativeLanguageInstructions() {
    final selected = _model.language ?? 'English';
    const localeNames = <String, String>{
      'English': 'English (en)',
      'Russian': 'Russian (ru)',
      'Turkish': 'Turkish (tr)',
      'Simplified Chinese': 'Simplified Chinese (zh-CN)',
      'Spanish': 'Spanish (es)',
      'French': 'French (fr)',
    };
    final locale = localeNames[selected] ?? selected;
    return '''Write the ORIGINAL itinerary directly in $locale. Do not draft in English and translate. All narrative, headlines, notes and section labels must be natural, grammatical $locale as written by an experienced native-language travel editor. Do not translate word for word or use awkward calques, invented words or filler. Keep proper names of attractions, neighborhoods and transit stations searchable in their actual official names. Use the requested language for all other text. Before returning, proofread for spelling, agreement, natural idiom, clean headings and accidental English instruction text. Never expose internal instructions or editorial notes.''';
  }

  String _buildGuideInstructions() {
    final selectedInterests = _model.interests.join(', ');
    final mobility = _model.gettingAround ?? 'Walking + Public Transit';
    final rules = <String>[
      'TRAVELER PREFERENCES: Interests: $selectedInterests. Transportation: $mobility.',
      'TASK: Return one COMPLETE, useful, polished day-by-day city itinerary, not a conversation. Do not ask questions, apologize for not being a human, invite follow-up or describe how you generated it. If insufficient reliable information exists, return an explicit failure instead of inventing places.',
      'DESTINATION: Every numbered stop must be a real, geographically valid and map-searchable attraction/activity within the requested city. Order stops to minimize unnecessary backtracking. Do not invent venue names, prices, opening hours or sources. No intercity excursions unless explicitly requested.',
      'STRUCTURE: Start with city name and a short overview. Label each day clearly (Day 1 / equivalent in the selected language). Each day has a short natural title, logical schedule and a numbered list of real attractions: 1) Official Place Name; 2) Official Place Name; etc. Restart numbering at 1 each day. Each attraction includes estimated visit time, approximate duration, why to go, and directions to the next stop. Keep descriptions precise and genuinely useful.',
      'NUMBERING: Only actual map-ready attraction/activity stops receive numbers. Meals, coffee, restaurants, generic breaks, transportation, practical tips and optional nearby shops must NOT be numbered. Do NOT print instructions such as NO NUMBERING, unnumbered, TODO, placeholders or model notes in the guide.',
      'STYLE: Write concise, fluent native-language travel editorial prose. Avoid literal English translations, nonsense words, unnatural category labels, robotic repetition and phrases such as independent coffee shop translated mechanically. Never use placeholders (e.g., some cafe, such-and-such dishes) as if they were specific recommendations. Do not repeat redundant Official Name and Why Visit labels for every stop.',
      'FOOD: Add useful optional meal suggestions separate from the numbered attraction route; name actual verified restaurants only when reliable, otherwise recommend the cuisine or neighborhood without inventing a venue. Never claim a menu item is available without evidence.',
      'FACTS: Say Free entry or Paid entry only when reasonably supported. Provide exact admission prices and official websites only when reliable; otherwise state that price is unconfirmed and should be verified on the official site. Use realistic walking and transport guidance; no invented schedules.',
      'END: Short practical Getting Around, local tips, bookings and estimated daily budget only where useful. No chatty concluding question or offer to do more.'
    ];
    if (_foodPreference == 'Vegetarian') {
      rules.add('DIET: Vegetarian. Exclude meat, poultry, fish and seafood in meal suggestions; eggs and dairy may be included. If a menu cannot be verified, say so rather than claiming compliance.');
    } else if (_foodPreference == 'Vegan') {
      rules.add('DIET: Vegan. Exclude meat, poultry, fish, seafood, dairy, eggs, honey and animal-derived ingredients in meal suggestions. If a menu cannot be verified, say so rather than claiming compliance.');
    }
    if (_model.interests.contains('Local Gems')) {
      rules.add('LOCAL GEMS: Favor real less-touristy streets, small galleries, genuine neighborhood experiences and local favorites when justified. Do not claim a place is popular with residents without evidence. Still meet the other chosen interests.');
    }
    if (_model.interests.contains('Local Markets')) {
      rules.add('LOCAL MARKETS: Add a short separate OPTIONAL Nearby Local Markets section with genuinely nearby food markets or supermarkets. Include real searchable names and addresses when reliable. These are not numbered sightseeing stops. Avoid detours and invented stores or hours.');
    }
    return rules.join('\n\n');
  }

  Future<void> _generateTrip() async {
    if (_model.isLoading == true) return;
    setState(() => _model.isLoading = true);
    try {
      final response = await GenerateTripCall.call(
        city: _model.city,
        days: (_model.days ?? 2).toString(),
        interests: _buildGuideInstructions(),
        language: _buildNativeLanguageInstructions(),
      );

      if (!mounted) return;
      if (!response.succeeded) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Trip generation failed (${response.statusCode}).')),
        );
        return;
      }

      final itinerary = GenerateTripCall.itinerary(response.jsonBody)?.trim() ?? '';
      // Reject chat-style and incomplete responses before showing PDF/Maps.
      final normalized = itinerary.toLowerCase();
      final hasDay = RegExp(r'(day\s*1|день\s*1|gün\s*1|día\s*1|jour\s*1|第[一1]天)', caseSensitive: false).hasMatch(itinerary);
      final looksLikeChat = normalized.contains('quick question') ||
          normalized.contains('before i build') ||
          normalized.contains('would you like me') ||
          normalized.contains('let me know if') ||
          normalized.contains('do you want me to') ||
          normalized.contains('хотите, чтобы я') ||
          normalized.contains('isterseniz') ||
          normalized.contains('нет нумерации') ||
          normalized.contains('no numbering') ||
          normalized.contains('булочнойми') ||
          normalized.contains('дентра с намеской') ||
          normalized.contains('такие-то') ||
          normalized.contains('независимую кафейню');
      if (itinerary.isEmpty || !hasDay || looksLikeChat) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('We could not complete a reliable itinerary. Please retry; no purchase was made.')),
        );
        return;
      }

      // Generate only once; show the first stop before unlocking the complete guide.
      await _showTripPreview(itinerary);

    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not create trip: $e')),
      );
    } finally {
      if (mounted) setState(() => _model.isLoading = false);
    }
  }

  // Display model content as data rather than asking Mai to format the UI.
  // Tolerate numbered stops with Markdown, localized punctuation and section headings.
  Map<String, String> _firstPreviewStop(String itinerary) {
    // Extract the first *real* stop without relying on English labels, Markdown,
    // or a particular numbering separator. Keep source text unchanged for My Trips.
    final lines = itinerary.replaceAll('\r\n', '\n').split('\n');
    final dayPattern = RegExp(
      r'(?:\bday\s*(?:1|one)\b|\bдень\s*1\b|\b1\s*[-.]?\s*(?:й|ый)?\s*день\b|\b(?:gün\s*1|1\s*\.?\s*gün)\b|\b(?:día\s*1|1\s*\.?\s*día)\b|\b(?:jour\s*1|1\s*er?\s*jour)\b|第[一1]天|第一日)',
      caseSensitive: false,
    );
    final stopPattern = RegExp(
      r'^\s*(?:[-*•]\s*)?(?:(?:stop|остановка|parada|arrêt|durak|站点|景点)\s*)?([1１])\s*[.)\-:、．]\s*(.+)$',
      caseSensitive: false,
    );
    final boldNumber = RegExp(r'^\s*\*\*\s*([1１])\s*[.)\-:、．]\s*(.+)');
    final numberedHeading = RegExp(r'^\s*#{1,6}\s*(?:[1１]\s*[.)\-:、．]\s*)?(.+)$');
    final timePattern = RegExp(r'\b(?:0?[7-9]|1[0-9]|2[0-3])[:.][0-5][0-9]\b');
    final numberedCandidates = <int>[];
    final headingCandidates = <int>[];
    var firstDayIndex = -1;

    String clean(String raw) => raw.trim()
        .replaceAll(RegExp(r'^#{1,6}\s*'), '')
        .replaceAll(RegExp(r'\*\*|__|`'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    bool isInvalidTitle(String value) {
      final v = value.toLowerCase().trim();
      if (v.length < 3 || dayPattern.hasMatch(v)) return true;
      return RegExp(
        r'^(?:theme|тема|транспорт|transport|time|время|продолжительность|duration|'
        r'getting around|local tips|good to know|food|breakfast|lunch|dinner|'
        r'завтрак|обед|ужин|советы|как добраться|budget|бюджет|'
        r'my city days|overview|маршрут|itinéraire|itinerary|resumen|özet)\b',
        caseSensitive: false,
      ).hasMatch(v);
    }

    for (var i = 0; i < lines.length; i++) {
      final raw = lines[i].trim();
      if (firstDayIndex < 0 && dayPattern.hasMatch(clean(raw))) {
        firstDayIndex = i;
        continue;
      }
      final plain = clean(raw);
      if (stopPattern.hasMatch(plain) || boldNumber.hasMatch(raw)) {
        numberedCandidates.add(i);
      } else if (numberedHeading.hasMatch(raw) && !isInvalidTitle(plain)) {
        headingCandidates.add(i);
      }
    }

    // Prefer stop #1 after the first day heading, but tolerate server output
    // without that exact heading. A generic bold section is the last fallback.
    int? index;
    for (final candidate in numberedCandidates) {
      if (candidate > firstDayIndex) { index = candidate; break; }
    }
    if (index == null && numberedCandidates.isNotEmpty) index = numberedCandidates.first;
    if (index == null) {
      for (final candidate in headingCandidates) {
        if (candidate > firstDayIndex && !isInvalidTitle(clean(lines[candidate]))) {
          index = candidate;
          break;
        }
      }
    }
    if (index == null) return {};

    final raw = lines[index].trim();
    final plain = clean(raw);
    String title = stopPattern.firstMatch(plain)?.group(2) ??
        boldNumber.firstMatch(raw)?.group(2) ??
        numberedHeading.firstMatch(raw)?.group(1) ?? '';
    title = clean(title).replaceFirst(RegExp(r'^[1１]\s*[.)\-:、．]\s*'), '');
    if (isInvalidTitle(title)) return {};

    final details = <String>[];
    var time = '';
    for (var j = index + 1; j < lines.length && j < index + 15; j++) {
      final next = clean(lines[j]);
      if (next.isEmpty) {
        if (details.isNotEmpty) break;
        continue;
      }
      if (dayPattern.hasMatch(next) || stopPattern.hasMatch(next) ||
          boldNumber.hasMatch(lines[j]) || lines[j].trimLeft().startsWith('#')) break;
      if (time.isEmpty) time = timePattern.firstMatch(next)?.group(0) ?? '';
      details.add(next.replaceFirst(RegExp(r'^[-*•]\s*'), ''));
      if (details.join(' ').length >= 340) break;
    }
    return {'title': title, 'description': details.join(' ').trim(), 'time': time};
  }

  Future<void> _showTripPreview(String itinerary) async {
    final stop = _firstPreviewStop(itinerary);
    if (stop.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('We could not identify the first stop. Please try creating your itinerary again.'),
      ));
      return;
    }
    final city = _model.city ?? 'Your Trip';
    final days = _model.days ?? 2;
    final theme = FlutterFlowTheme.of(context);
    final unlock = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Container(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(sheetContext).height * .91),
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 18),
          decoration: BoxDecoration(
            color: theme.primaryBackground,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(color: theme.alternate, borderRadius: BorderRadius.circular(30)),
                )),
                const SizedBox(height: 18),
                Text('MY CITY DAYS  ·  PREVIEW', style: theme.bodySmall.copyWith(
                  color: theme.secondaryText, fontWeight: FontWeight.w700, letterSpacing: 1.2,
                )),
                const SizedBox(height: 9),
                Text(city.toUpperCase(), style: theme.headlineMedium.copyWith(fontWeight: FontWeight.w800)),
                Text('$days-day personalized itinerary', style: theme.bodyMedium.copyWith(color: theme.secondaryText)),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    color: theme.secondaryBackground,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: theme.alternate),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('DAY 1 · YOUR FIRST DISCOVERY', style: theme.bodySmall.copyWith(
                      color: theme.secondaryText, fontWeight: FontWeight.w700, letterSpacing: .7,
                    )),
                    const SizedBox(height: 12),
                    Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(Icons.place_outlined, color: theme.primary, size: 22),
                      const SizedBox(width: 7),
                      Expanded(child: Text(stop['title']!, style: theme.titleMedium.copyWith(fontWeight: FontWeight.bold))),
                    ]),
                    if (stop['description']!.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(stop['description']!, maxLines: 5, overflow: TextOverflow.ellipsis,
                        style: theme.bodyMedium.copyWith(height: 1.5)),
                    ],
                    if (stop['time']!.isNotEmpty) ...[
                      const SizedBox(height: 11),
                      Row(children: [
                        Icon(Icons.schedule_outlined, size: 16, color: theme.secondaryText),
                        const SizedBox(width: 6),
                        Text(stop['time']!, style: theme.bodySmall),
                      ]),
                    ],
                  ]),
                ),
                const SizedBox(height: 13),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 19),
                  decoration: BoxDecoration(
                    color: theme.secondaryBackground,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: theme.alternate),
                  ),
                  child: Column(children: [
                    Icon(Icons.lock_outline_rounded, color: theme.primaryText, size: 26),
                    const SizedBox(height: 8),
                    Text('Your next discoveries await', style: theme.titleMedium.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text('Unlock the remaining stops, Google Maps routes and your complete PDF guide.',
                      textAlign: TextAlign.center, style: theme.bodySmall.copyWith(color: theme.secondaryText)),
                  ]),
                ),
                const SizedBox(height: 16),
                // Keep the existing one-trip $8.99 button style and wording.
                SizedBox(height: 54, child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.primary, foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  ),
                  onPressed: () => Navigator.of(sheetContext).pop(true),
                  child: const Text('Create My Trip · \$8.99', style: TextStyle(fontWeight: FontWeight.w700)),
                )),
                const SizedBox(height: 8),
                Text('No payment will be charged.', textAlign: TextAlign.center,
                  style: theme.bodySmall.copyWith(color: theme.secondaryText)),
              ],
            ),
          ),
        ),
      ),
    );
    if (unlock != true || !mounted) return;
    // No second AI request: navigate with the already generated itinerary.
    context.goNamed(MyTripWidget.routeName, queryParameters: {
      'itineraryId': serializeParam(itinerary, ParamType.String),
      'city': serializeParam(city, ParamType.String),
    }.withoutNulls);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('Plan your city days'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const SavedTripsPage()),
                    ),
                    icon: const Icon(Icons.bookmarks_outlined),
                    label: const Text('My Trips / History'),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Choose what you love and we'll shape the days around you.",
                    style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                          color: FlutterFlowTheme.of(context).secondaryText,
                        ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Popular Cities'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: popularCities
                        .map((c) => _choiceChip(c, _model.city == c, () {
                              setState(() {
                                _model.city = c;
                                _customCityController.clear();
                              });
                            }))
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: _sectionTitle('Beyond the Tourist Trail')),
                      TextButton(
                        onPressed: () => setState(
                          () => _showAllHiddenGems = !_showAllHiddenGems,
                        ),
                        style: TextButton.styleFrom(
                          foregroundColor: FlutterFlowTheme.of(context).tertiary,
                        ),
                        child: Text(_showAllHiddenGems ? 'Show less' : 'Show all'),
                      ),
                    ],
                  ),
                  Text(
                    'Explore smaller, less touristy cities with authentic local character.',
                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                      color: FlutterFlowTheme.of(context).secondaryText,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: (_showAllHiddenGems
                            ? hiddenGemCities
                            : hiddenGemCities.take(8))
                        .map((c) => _choiceChip(c, _model.city == c, () {
                              setState(() {
                                _model.city = c;
                                _customCityController.clear();
                              });
                            }))
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                  _sectionTitle('Enter Any City'),
                  TextField(
                    controller: _customCityController,
                    focusNode: _customCityFocusNode,
                    textCapitalization: TextCapitalization.words,
                    decoration: InputDecoration(
                      hintText: 'Type a city, e.g. Oslo',
                      prefixIcon: const Icon(Icons.search_rounded),
                      filled: true,
                      fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide(color: FlutterFlowTheme.of(context).tertiary, width: 1.5),
                      ),
                    ),
                    onChanged: (value) {
                      final city = value.trim();
                      setState(() => _model.city = city);
                    },
                    onSubmitted: (value) {
                      final city = value.trim();
                      setState(() => _model.city = city);
                    },
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('How many days?'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: List.generate(5, (index) {
                      final day = index + 1;
                      return _choiceChip(
                        '$day ${day == 1 ? 'Day' : 'Days'}',
                        _model.days == day,
                        () => setState(() => _model.days = day),
                      );
                    }),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle("What's your vibe?"),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: interestOptions.map((interest) {
                      final selected = _model.interests.contains(interest);
                      return FilterChip(
                        label: Text(interest),
                        selected: selected,
                        showCheckmark: true,
                        checkmarkColor: Colors.white,
                        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
                        selectedColor: FlutterFlowTheme.of(context).primary,
                        side: BorderSide.none,
                        labelStyle: TextStyle(
                          color: selected ? Colors.white : FlutterFlowTheme.of(context).primaryText,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                        ),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        onSelected: (value) {
                          setState(() {
                            if (value) {
                              if (!_model.interests.contains(interest)) {
                                _model.interests.add(interest);
                              }
                            } else {
                              _model.interests.remove(interest);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Local Gems: explore authentic neighborhoods and places locals love. Local Markets: optional nearby grocery stores, produce markets and supermarkets (not sightseeing stops).',
                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                      color: FlutterFlowTheme.of(context).secondaryText,
                    ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Food Preferences'),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: foodPreferenceOptions
                        .map((preference) => _choiceChip(
                              preference,
                              _foodPreference == preference,
                              () => setState(() => _foodPreference = preference),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Vegetarian excludes meat and fish. Vegan excludes all animal products, including dairy, eggs and honey. Always verify ingredients with the restaurant.',
                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                      color: FlutterFlowTheme.of(context).secondaryText,
                    ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Getting Around'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: transportOptions
                        .map((transport) => _choiceChip(
                              transport,
                              _model.gettingAround == transport,
                              () => setState(() => _model.gettingAround = transport),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Preferred Language'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: languageOptions
                        .map((language) => _choiceChip(
                              language,
                              _model.language == language,
                              () => setState(() => _model.language = language),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 36),
                  SizedBox(
                    height: 54,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: FlutterFlowTheme.of(context).primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                      onPressed: _model.isLoading == true ? null : _createTrip,
                      icon: _model.isLoading == true
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.auto_awesome_rounded),
                      label: Text(_model.isLoading == true
                          ? 'Creating your trip...'
                          : 'Create My Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
