import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Local offline history for the TEST build only.
/// This is not a purchase ledger and is not a cloud backup.
class TripHistoryStore {
  static const _key = 'my_city_days_local_trips_v1';

  static Future<List<Map<String, dynamic>>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final parsed = jsonDecode(raw);
      if (parsed is! List) return [];
      return parsed.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> save({required String city, required String itinerary}) async {
    if (itinerary.trim().isEmpty) return;
    final records = await load();
    // Avoid a duplicate when navigating back to the same already generated trip.
    if (records.any((e) => e['city'] == city && e['itinerary'] == itinerary)) return;
    records.insert(0, {
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'city': city.trim().isEmpty ? 'My Trip' : city.trim(),
      'itinerary': itinerary,
      'createdAt': DateTime.now().toIso8601String(),
      'accessType': 'test',
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(records));
  }

  /// Record a map generated for a specific saved trip. Local test storage only.
  static Future<void> recordMap({required String city, required String itinerary,
    required int day, required String url}) async {
    final records = await load();
    final index = records.indexWhere((e) => e['city'] == city && e['itinerary'] == itinerary);
    if (index < 0) return;
    final maps = Map<String, dynamic>.from(records[index]['mapUrls'] as Map? ?? {});
    maps[day.toString()] = url;
    records[index]['mapUrls'] = maps;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(records));
  }

  /// Log successful PDF export, not a store purchase and not a retained PDF file.
  static Future<void> recordDownload({required String city, required String itinerary}) async {
    final records = await load();
    final index = records.indexWhere((e) => e['city'] == city && e['itinerary'] == itinerary);
    if (index < 0) return;
    final downloads = List<String>.from(records[index]['pdfExports'] as List? ?? []);
    downloads.add(DateTime.now().toIso8601String());
    records[index]['pdfExports'] = downloads;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(records));
  }

}
