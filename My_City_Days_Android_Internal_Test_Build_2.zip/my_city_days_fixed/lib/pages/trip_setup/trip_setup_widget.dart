import 'dart:async';

import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'trip_setup_model.dart';
export 'trip_setup_model.dart';

class TripSetupWidget extends StatefulWidget {
  const TripSetupWidget({super.key});

  static String routeName = 'TripSetup';
  static String routePath = '/tripSetup';

  @override
  State<TripSetupWidget> createState() => _TripSetupWidgetState();
}

class _TripSetupWidgetState extends State<TripSetupWidget> {
  late TripSetupModel _model;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  late final TextEditingController _customCityController;
  late final FocusNode _customCityFocusNode;
  bool _showAllHiddenGems = false;

  static const String _oneTripProductId = 'com.abisheva.mycitydays.onetrip';
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;
  ProductDetails? _oneTripProduct;
  bool _storeAvailable = false;
  bool _purchaseInProgress = false;
  bool _purchaseRequested = false;
  bool _paywallOpen = false;

  final popularCities = const [
    'New York',
    'Paris',
    'Tokyo',
    'Rome',
    'London',
    'Barcelona',
    'Dubai',
    'Istanbul',
    'San Francisco',
    'San Diego',
  ];
  final hiddenGemCities = const [
    'Santa Barbara',
    'Savannah',
    'Portland, Maine',
    'Ljubljana',
    'Bologna',
    'Zaragoza',
    'Tbilisi',
    'Plovdiv',
    'Almaty',
    'Tashkent',
    'Samarkand',
    'Bukhara',
    'Kanazawa',
    'Fukuoka',
    'Busan',
    'Gyeongju',
    'Chengdu',
    'Chongqing',
    'Shenzhen',
  ];
  final interestOptions = const ['Food', 'Culture', 'Shopping', 'Nature', 'Local Gems'];
  final languageOptions = const ['English', 'Russian', 'Turkish', 'Simplified Chinese'];
  final transportOptions = const ['Walking + Public Transit', 'Rideshare', 'Car'];

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TripSetupModel());
    _customCityController = TextEditingController();
    _customCityFocusNode = FocusNode();
    _initStore();
  }

  Future<void> _initStore() async {
    if (kIsWeb) return;

    _purchaseSubscription = _iap.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: (Object error) {
        if (!mounted) return;
        setState(() => _purchaseInProgress = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Purchase error: $error')),
        );
      },
    );

    try {
      final available = await _iap.isAvailable();
      if (!mounted) return;
      if (!available) {
        setState(() => _storeAvailable = false);
        return;
      }

      final response = await _iap.queryProductDetails({_oneTripProductId});
      if (!mounted) return;
      setState(() {
        _storeAvailable = response.error == null && response.productDetails.isNotEmpty;
        _oneTripProduct = response.productDetails.isEmpty ? null : response.productDetails.first;
      });
    } catch (_) {
      if (mounted) setState(() => _storeAvailable = false);
    }
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.productID != _oneTripProductId) continue;

      if (purchase.status == PurchaseStatus.pending) {
        if (mounted) setState(() => _purchaseInProgress = true);
        continue;
      }

      if (purchase.status == PurchaseStatus.error ||
          purchase.status == PurchaseStatus.canceled) {
        if (mounted) {
          setState(() => _purchaseInProgress = false);
          if (purchase.status == PurchaseStatus.error) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(purchase.error?.message ?? 'Purchase could not be completed.')),
            );
          }
        }
        _purchaseRequested = false;
      }

      if (purchase.status == PurchaseStatus.purchased) {
        if (purchase.pendingCompletePurchase) {
          await _iap.completePurchase(purchase);
        }

        final shouldCreateTrip = _purchaseRequested;
        _purchaseRequested = false;
        if (!mounted) return;
        setState(() => _purchaseInProgress = false);

        if (shouldCreateTrip) {
          if (_paywallOpen && Navigator.of(context).canPop()) {
            Navigator.of(context).pop();
            _paywallOpen = false;
          }
          await _generateTrip();
        }
      } else if (purchase.pendingCompletePurchase) {
        await _iap.completePurchase(purchase);
      }
    }
  }

  @override
  void dispose() {
    _purchaseSubscription?.cancel();
    _customCityController.dispose();
    _customCityFocusNode.dispose();
    _model.dispose();
    super.dispose();
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(
          text,
          style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
      );

  Widget _choiceChip(String label, bool selected, VoidCallback onTap) {
    return ChoiceChip(
      label: Text(label),
      avatar: selected
          ? const Icon(Icons.check_rounded, size: 16, color: Colors.white)
          : null,
      selected: selected,
      showCheckmark: false,
      backgroundColor: const Color(0xFFF0EEE9),
      selectedColor: FlutterFlowTheme.of(context).primary,
      side: BorderSide.none,
      labelStyle: TextStyle(
        color: selected ? Colors.white : FlutterFlowTheme.of(context).primaryText,
        fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      onSelected: (_) => onTap(),
    );
  }

  Future<void> _createTrip() async {
    if (_model.isLoading == true || _purchaseInProgress) return;
    if ((_model.city ?? '').isEmpty ||
        (_model.language ?? '').isEmpty ||
        _model.interests.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose a city, interests and language.')),
      );
      return;
    }

    await _showPaywall();
  }

  Future<void> _showPaywall() async {
    final price = _oneTripProduct?.price ?? r'$8.99';

    _paywallOpen = true;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 42,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 22),
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).alternate,
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6E8DD),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        Icons.explore_rounded,
                        color: FlutterFlowTheme.of(context).primary,
                        size: 30,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Your personalized trip is ready',
                      style: FlutterFlowTheme.of(context).headlineSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Before you purchase, here’s exactly what is included in your one-time trip purchase.',
                      style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                            color: FlutterFlowTheme.of(context).secondaryText,
                            height: 1.45,
                          ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'What you’ll get',
                      style: FlutterFlowTheme.of(context).titleSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 10),
                    _paywallFeature(Icons.route_rounded, 'Personalized day-by-day itinerary'),
                    _paywallFeature(Icons.restaurant_rounded, 'Recommendations, food spots & local gems'),
                    _paywallFeature(Icons.lightbulb_outline_rounded, 'Practical travel tips for your destination'),
                    _paywallFeature(Icons.map_rounded, 'Google Maps routes for your days'),
                    _paywallFeature(Icons.picture_as_pdf_rounded, 'Downloadable My City Days guide'),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6E8DD),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        'One-time in-app purchase · $price per trip · No subscription',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                              fontWeight: FontWeight.w700,
                              color: FlutterFlowTheme.of(context).primaryText,
                            ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('One personalized trip',
                                    style: FlutterFlowTheme.of(context).bodyLarge.copyWith(
                                          fontWeight: FontWeight.w700,
                                        )),
                                const SizedBox(height: 3),
                                Text('One-time purchase',
                                    style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                                          color: FlutterFlowTheme.of(context).secondaryText,
                                        )),
                              ],
                            ),
                          ),
                          Text(
                            price,
                            style: FlutterFlowTheme.of(context).titleLarge.copyWith(
                                  fontWeight: FontWeight.w800,
                                ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 56,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: FlutterFlowTheme.of(context).primary,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        onPressed: _purchaseInProgress
                            ? null
                            : () async {
                                setSheetState(() => _purchaseInProgress = true);
                                if (mounted) {
                                  setState(() => _purchaseInProgress = true);
                                }
                                Navigator.of(sheetContext).pop();
                                _paywallOpen = false;
                                if (mounted) {
                                  setState(() => _purchaseInProgress = false);
                                }
                                await _generateTrip();
                              },
                        child: _purchaseInProgress
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Create My Trip · $price',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Internal test · No payment will be charged. Tap the button to continue.',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodySmall.copyWith(
                            color: FlutterFlowTheme.of(context).secondaryText,
                          ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
    _paywallOpen = false;
  }

  Widget _paywallFeature(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFF6E8DD),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, size: 19, color: FlutterFlowTheme.of(context).tertiary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _generateTrip() async {
    if (_model.isLoading == true) return;
    setState(() => _model.isLoading = true);
    try {
      final response = await GenerateTripCall.call(
        city: _model.city,
        days: (_model.days ?? 2).toString(),
        interests: '''${_model.interests.join(', ')}. Getting around: ${_model.gettingAround}. Build a polished personal city guide, not a generic list. Group nearby places and minimize backtracking. Never send the traveler back to a neighborhood already visited that day unless there is a compelling reason. Do not force a fixed number of stops. CITY BOUNDARY RULE: every numbered route stop MUST be physically located in the selected city. Never mix attractions from another city into the itinerary, even if they are famous or nearby. Do not create intercity day trips unless the user explicitly requested one. IMPORTANT FOR MAPS: number ONLY concrete sightseeing/activity POIs that belong in the day's route. Never number breakfast, lunch, dinner, cafes, restaurants, bars, bakeries, food markets used primarily as meal stops, food recommendations, neighborhood-only meal suggestions, or generic activities such as Dinner in North Beach. Specific restaurant names must also stay unnumbered. Put food recommendations in separate unnumbered lines/sections. Every numbered route stop must begin with the official/canonical place name that Google Maps can resolve. Preserve proper-noun POI names in their official Latin/local-script form even when the guide language is Russian, Turkish, or Simplified Chinese; translate the explanation, not the searchable proper name. Do not put translated prose inside the place name. For each route stop include approximate time, suggested duration, why it is worth visiting, a practical My City Days tip, and how to reach the next stop. For food recommendations include what to order, price level, and whether reservations are useful. Give each day a neighborhood/theme, rough duration, walking level and transport notes. Add an Evening Option where appropriate. End with Getting Around, Local Tips, What to Book Ahead, and Estimated Daily Budget. GETTING AROUND TIPS: tailor this section to the traveler’s selected transport and keep it short and practical. For Walking + Public Transit, name the relevant local transit system, fare card/app or common payment method when confidently known (for example Muni/Clipper, PRONTO/Trolley), plus 1–2 useful usage tips. For Rideshare, mention the commonly used local rideshare/taxi apps or services when confidently known and one practical pickup/payment tip. For Car, include 2–4 concise driving/parking tips: where parking is typically easier or cheaper, evening/weekend garage rates when reliably known, tolls or access restrictions, and when it is smarter to park once and walk. If rental information is useful, briefly say whether airport/downtown rental is usually convenient, but do not invent companies, addresses, prices, parking rates, schedules, or live availability. If a specific fare, parking price, schedule, app/service, or rule may be time-sensitive and cannot be verified from current data, describe it without an exact number and tell the traveler to verify the current rate/rule. Do not add this as a new screen; keep it inside the existing Getting Around/Local Tips sections. Do not add chatbot-style introductions or closing offers such as If you want, Хотите, İsterseniz, or 需要我.''',
        language: _model.language,
      );

      if (!mounted) return;
      if (!response.succeeded) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Trip generation failed (${response.statusCode}).')),
        );
        return;
      }

      final itinerary = GenerateTripCall.itinerary(response.jsonBody)?.trim() ?? '';
      if (itinerary.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('The AI returned an empty itinerary. Please try again.')),
        );
        return;
      }

      context.goNamed(
        MyTripWidget.routeName,
        queryParameters: {
          'itineraryId': serializeParam(itinerary, ParamType.String),
          'city': serializeParam(_model.city, ParamType.String),
        }.withoutNulls,
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not create trip: $e')),
      );
    } finally {
      if (mounted) setState(() => _model.isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => context.safePop(),
        ),
        title: const Text('Plan your city days'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    "Choose what you love and we'll shape the days around you.",
                    style: FlutterFlowTheme.of(context).bodyMedium.copyWith(
                          color: FlutterFlowTheme.of(context).secondaryText,
                        ),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Popular Cities'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: popularCities
                        .map((c) => _choiceChip(c, _model.city == c, () {
                              setState(() {
                                _model.city = c;
                                _customCityController.clear();
                              });
                            }))
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: _sectionTitle('Hidden Gems')),
                      TextButton(
                        onPressed: () => setState(
                          () => _showAllHiddenGems = !_showAllHiddenGems,
                        ),
                        style: TextButton.styleFrom(
                          foregroundColor: FlutterFlowTheme.of(context).tertiary,
                        ),
                        child: Text(_showAllHiddenGems ? 'Show less' : 'Show all'),
                      ),
                    ],
                  ),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: (_showAllHiddenGems
                            ? hiddenGemCities
                            : hiddenGemCities.take(8))
                        .map((c) => _choiceChip(c, _model.city == c, () {
                              setState(() {
                                _model.city = c;
                                _customCityController.clear();
                              });
                            }))
                        .toList(),
                  ),
                  const SizedBox(height: 22),
                  _sectionTitle('Enter Any City'),
                  TextField(
                    controller: _customCityController,
                    focusNode: _customCityFocusNode,
                    textCapitalization: TextCapitalization.words,
                    decoration: InputDecoration(
                      hintText: 'Type a city, e.g. Oslo',
                      prefixIcon: const Icon(Icons.search_rounded),
                      filled: true,
                      fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide(color: FlutterFlowTheme.of(context).alternate),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                        borderSide: BorderSide(color: FlutterFlowTheme.of(context).tertiary, width: 1.5),
                      ),
                    ),
                    onChanged: (value) {
                      final city = value.trim();
                      setState(() => _model.city = city);
                    },
                    onSubmitted: (value) {
                      final city = value.trim();
                      setState(() => _model.city = city);
                    },
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('How many days?'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: List.generate(5, (index) {
                      final day = index + 1;
                      return _choiceChip(
                        '$day ${day == 1 ? 'Day' : 'Days'}',
                        _model.days == day,
                        () => setState(() => _model.days = day),
                      );
                    }),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle("What's your vibe?"),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: interestOptions.map((interest) {
                      final selected = _model.interests.contains(interest);
                      return FilterChip(
                        label: Text(interest),
                        selected: selected,
                        showCheckmark: true,
                        checkmarkColor: Colors.white,
                        backgroundColor: const Color(0xFFF0EEE9),
                        selectedColor: FlutterFlowTheme.of(context).primary,
                        side: BorderSide.none,
                        labelStyle: TextStyle(
                          color: selected ? Colors.white : FlutterFlowTheme.of(context).primaryText,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                        ),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        onSelected: (value) {
                          setState(() {
                            if (value) {
                              if (!_model.interests.contains(interest)) {
                                _model.interests.add(interest);
                              }
                            } else {
                              _model.interests.remove(interest);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Getting Around'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: transportOptions
                        .map((transport) => _choiceChip(
                              transport,
                              _model.gettingAround == transport,
                              () => setState(() => _model.gettingAround = transport),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 28),
                  _sectionTitle('Preferred Language'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: languageOptions
                        .map((language) => _choiceChip(
                              language,
                              _model.language == language,
                              () => setState(() => _model.language = language),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 36),
                  SizedBox(
                    height: 54,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: FlutterFlowTheme.of(context).primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                      onPressed: _model.isLoading == true ? null : _createTrip,
                      icon: _model.isLoading == true
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.auto_awesome_rounded),
                      label: Text(_model.isLoading == true
                          ? 'Creating your trip...'
                          : 'Create My Trip'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
